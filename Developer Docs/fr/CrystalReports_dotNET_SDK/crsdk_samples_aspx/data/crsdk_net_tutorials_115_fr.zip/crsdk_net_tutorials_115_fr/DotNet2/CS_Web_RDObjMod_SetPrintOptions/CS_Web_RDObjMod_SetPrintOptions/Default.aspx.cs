﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Collections;

public partial class _Default : System.Web.UI.Page 
{
    private const string CURRENT_PRINTER = @"\\vanprt04\C3-8N-DOC";
    private ReportDocument hierarchicalGroupingReport;

    private void ConfigureCrystalReports()
    {
        hierarchicalGroupingReport = new ReportDocument();
        hierarchicalGroupingReport.Load(@"C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Hierarchical Grouping.rpt");
        crystalReportViewer.ReportSource = hierarchicalGroupingReport;

    }

    private void Page_Init(object sender, EventArgs e)
    {
        ConfigureCrystalReports();
    }

    private ArrayList GetPaperSources()
    {
        ArrayList arrayList = new ArrayList();
        System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
        printerSettings.PrinterName = CURRENT_PRINTER;
        foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
        {
            arrayList.Add(paperSource.SourceName.ToString());
        }
        return arrayList;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            paperOrientationList.DataSource = System.Enum.GetValues(typeof(PaperOrientation));
            paperSizeList.DataSource = System.Enum.GetValues(typeof(PaperSize));
            printerDuplexList.DataSource = System.Enum.GetValues(typeof(PrinterDuplex));
            paperSourceList.DataSource = GetPaperSources();
            DataBind();
        }
    }

    private System.Drawing.Printing.PaperSource GetSelectedPaperSource()
    {
        System.Drawing.Printing.PaperSource selectedPaperSource = new System.Drawing.Printing.PaperSource();
        System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
        printerSettings.PrinterName = CURRENT_PRINTER;
        foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
        {
            if (paperSource.SourceName == paperSourceList.SelectedItem.Text)
            {
                selectedPaperSource = paperSource;
            }
        }
        return selectedPaperSource;
    }

    private void SetPrintOptions()
    {
        PrintOptions printOptions = hierarchicalGroupingReport.PrintOptions;
        printOptions.PrinterName = CURRENT_PRINTER;
        printOptions.PaperOrientation = (PaperOrientation)paperOrientationList.SelectedIndex;
        printOptions.PaperSize = (PaperSize)paperSizeList.SelectedIndex;
        printOptions.PrinterDuplex = (PrinterDuplex)printerDuplexList.SelectedIndex;
        printOptions.CustomPaperSource = GetSelectedPaperSource();
    }

    protected void printReport_Click(object sender, EventArgs e)
    {
        SetPrintOptions();
        try
        {
            hierarchicalGroupingReport.PrintToPrinter(1, false, 1, 99);
            message.Text = MessageConstants.SUCCESS;

        }
        catch (Exception ex)
        {
            message.Text = MessageConstants.FAILURE + ex.Message;
        }

    }
}
