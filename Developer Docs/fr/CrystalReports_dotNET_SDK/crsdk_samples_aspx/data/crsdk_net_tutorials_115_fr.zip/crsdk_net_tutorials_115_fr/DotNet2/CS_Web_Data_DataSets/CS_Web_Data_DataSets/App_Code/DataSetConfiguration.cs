using System;
using System.Data;
using System.IO;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

public class DataSetConfiguration
{
    private const string CONNECTION_STRING = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Program Files\Business Objects\Common\3.5\Samples\En\Databases\xtreme.mdb";
    private const string QUERY_STRING = "SELECT * FROM CUSTOMER";
    private const string DATATABLE_NAME = "Customer";
    private const string DIRECTORY_FILE_PATH = "";

    public static DataSet CustomerDataSet
    {
        get
        {
            DataSet dataSet = new DataSet();
            dataSet.ReadXmlSchema(@"C:\TutorialSampleCodeProjects\CS_Web_Data_DataSets\CS_Web_Data_DataSets\XMLSchema.xsd");
            OleDbConnection oleDbConnection = new OleDbConnection(CONNECTION_STRING);
            OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(QUERY_STRING, oleDbConnection);
            oleDbDataAdapter.Fill(dataSet, DATATABLE_NAME);
            return dataSet;
        }
    }


}
