using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Web_RDObjMod_SessionPersistence
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button sortOrderDescending;
		protected System.Web.UI.WebControls.Button sortOrderAscending;
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
		private Hierarchical_Grouping hierarchicalGroupingReport;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void ConfigureCrystalReports()
		{
			if (Session["hierarchicalGroupingReport"] == null)
			{
				hierarchicalGroupingReport = new Hierarchical_Grouping();
				Session["hierarchicalGroupingReport"] = hierarchicalGroupingReport;
			}
			else
			{
				hierarchicalGroupingReport = (Hierarchical_Grouping)Session["hierarchicalGroupingReport"];
			}

			crystalReportViewer.ReportSource = hierarchicalGroupingReport;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sortOrderDescending.Click += new System.EventHandler(this.sortOrderDescending_Click);
			this.sortOrderAscending.Click += new System.EventHandler(this.sortOrderAscending_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void sortOrderDescending_Click(object sender, System.EventArgs e)
		{
			SortFields sortFields = hierarchicalGroupingReport.DataDefinition.SortFields;
			SortField firstSortField = sortFields[0];
			firstSortField.SortDirection = SortDirection.DescendingOrder;
			Session["hierarchicalGroupingReport"] = hierarchicalGroupingReport;
			ConfigureCrystalReports();
		}

		private void sortOrderAscending_Click(object sender, System.EventArgs e)
		{
			SortFields sortFields = hierarchicalGroupingReport.DataDefinition.SortFields;
			SortField firstSortField = sortFields[0];
			firstSortField.SortDirection = SortDirection.AscendingOrder;
			Session["hierarchicalGroupingReport"] = hierarchicalGroupingReport;
			ConfigureCrystalReports();		
		}
	}
}
