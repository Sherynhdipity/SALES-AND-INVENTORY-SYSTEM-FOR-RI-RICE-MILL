using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjMod_FilteringData
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{

		private CustomerBySalesName customerBySalesNameReport;
		private string salesAmount;
		private string operatorValue;
		private string customerName;


		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox lastYearsSales;
		private System.Windows.Forms.ComboBox operatorValueList;
		private System.Windows.Forms.Button redisplay;
		private System.Windows.Forms.Label formula;
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		private System.Windows.Forms.TextBox name;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			salesAmount = "11000";
			operatorValue = "=";
			customerName = "A";
			operatorValueList.DataSource = System.Enum.GetValues(typeof(CeComparisonOperator));
			ConfigureCrystalReports();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		private void ConfigureCrystalReports()
		{
			string selectionFormula = "{Customer.Last Year's Sales} > "
				+ salesAmount
				+ " AND Mid({Customer.Customer Name}, 1, 1) "
				+ operatorValue
				+ "'"
				+ customerName
				+ "'";

			customerBySalesNameReport = new CustomerBySalesName();
			customerBySalesNameReport.DataDefinition.RecordSelectionFormula = selectionFormula;
			crystalReportViewer.ReportSource = customerBySalesNameReport;
			formula.Text = selectionFormula;
		}

		private string GetSelectedOperator()
		{
			string selectedOperator = "";

			switch ((CeComparisonOperator)operatorValueList.SelectedIndex)
			{
				case CeComparisonOperator.EqualTo:
					selectedOperator = "=";
					break;
				case CeComparisonOperator.GreaterThan:
					selectedOperator = ">";
					break;
				case CeComparisonOperator.GreaterThanOrEqualTo:
					selectedOperator = ">=";
					break;
				case CeComparisonOperator.LessThan:
					selectedOperator = "<";
					break;
				case CeComparisonOperator.LessThanOrEqualTo:
					selectedOperator = "<=";
					break;
				case CeComparisonOperator.NotEqualTo:
					selectedOperator = "<>";
					break;
			}

			return selectedOperator;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.lastYearsSales = new System.Windows.Forms.TextBox();
			this.operatorValueList = new System.Windows.Forms.ComboBox();
			this.name = new System.Windows.Forms.TextBox();
			this.redisplay = new System.Windows.Forms.Button();
			this.formula = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.crystalReportViewer.Location = new System.Drawing.Point(0, 144);
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(640, 304);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(168, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Display the following customers:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(312, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(120, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "- last year\'s sales > $:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(312, 8);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(120, 23);
			this.label3.TabIndex = 3;
			this.label3.Text = "- first letter of name is";
			// 
			// lastYearsSales
			// 
			this.lastYearsSales.Location = new System.Drawing.Point(440, 40);
			this.lastYearsSales.Name = "lastYearsSales";
			this.lastYearsSales.TabIndex = 4;
			this.lastYearsSales.Text = "";
			// 
			// operatorValueList
			// 
			this.operatorValueList.Location = new System.Drawing.Point(184, 8);
			this.operatorValueList.Name = "operatorValueList";
			this.operatorValueList.Size = new System.Drawing.Size(121, 21);
			this.operatorValueList.TabIndex = 5;
			// 
			// name
			// 
			this.name.Location = new System.Drawing.Point(440, 8);
			this.name.Name = "name";
			this.name.TabIndex = 6;
			this.name.Text = "A";
			// 
			// redisplay
			// 
			this.redisplay.Location = new System.Drawing.Point(16, 104);
			this.redisplay.Name = "redisplay";
			this.redisplay.Size = new System.Drawing.Size(104, 23);
			this.redisplay.TabIndex = 7;
			this.redisplay.Text = "Redisplay Report";
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			// 
			// formula
			// 
			this.formula.Location = new System.Drawing.Point(136, 104);
			this.formula.Name = "formula";
			this.formula.Size = new System.Drawing.Size(440, 23);
			this.formula.TabIndex = 8;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 446);
			this.Controls.Add(this.formula);
			this.Controls.Add(this.redisplay);
			this.Controls.Add(this.name);
			this.Controls.Add(this.operatorValueList);
			this.Controls.Add(this.lastYearsSales);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.crystalReportViewer);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			salesAmount = lastYearsSales.Text;
			operatorValue = GetSelectedOperator();
			customerName = name.Text;

			ConfigureCrystalReports();
		}
	}
}
