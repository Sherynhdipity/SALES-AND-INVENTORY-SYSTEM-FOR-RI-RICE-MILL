using System;

namespace CS_Win_RDObjMod_FilteringData
{
	public enum CeComparisonOperator
	{
		EqualTo,
		LessThan,
		GreaterThan,
		LessThanOrEqualTo,
		GreaterThanOrEqualTo,
		NotEqualTo
	}
}
