using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjMod_SetPrintOptions
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private Hierarchical_Grouping hierarchicalGroupingReport;
		private const string CURRENT_PRINTER = @"\\VANPRT04\C3-8N-DOC";
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox paperOrientationList;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox paperSizeList;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox printerDuplexList;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox paperSourceList;
		private System.Windows.Forms.Button printReport;
		private System.Windows.Forms.Label message;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			paperOrientationList.DataSource = System.Enum.GetValues(typeof(PaperOrientation));
			paperSizeList.DataSource = System.Enum.GetValues(typeof(PaperSize));
			printerDuplexList.DataSource = System.Enum.GetValues(typeof(PrinterDuplex));
			paperSourceList.DataSource = GetPaperSources();
			ConfigureCrystalReports();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		private void ConfigureCrystalReports()
		{
			hierarchicalGroupingReport = new Hierarchical_Grouping();
			crystalReportViewer.ReportSource = hierarchicalGroupingReport;

		}

		private ArrayList GetPaperSources()
		{
			ArrayList arrayList = new ArrayList();
			System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
			printerSettings.PrinterName = CURRENT_PRINTER;

			foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
			{
				arrayList.Add(paperSource.SourceName.ToString());
			}
			return arrayList;
		}

		private System.Drawing.Printing.PaperSource GetSelectedPaperSource()
		{
			System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
			printerSettings.PrinterName = CURRENT_PRINTER;

			System.Drawing.Printing.PaperSource selectedPaperSource = printerSettings.PaperSources[0];
			
			foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
			{
				if (paperSource.SourceName == paperSourceList.SelectedText)
				{
					selectedPaperSource = paperSource;
				}
			}
			return selectedPaperSource;
		}


		private void SetPrintOptions()
		{
			PrintOptions printOptions = hierarchicalGroupingReport.PrintOptions;
			printOptions.PrinterName = CURRENT_PRINTER;
			printOptions.PaperOrientation = (PaperOrientation)paperOrientationList.SelectedIndex;
			printOptions.PaperSize = (PaperSize)paperSizeList.SelectedIndex;
			printOptions.PrinterDuplex = (PrinterDuplex)printerDuplexList.SelectedIndex;
			printOptions.CustomPaperSource = GetSelectedPaperSource();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.label1 = new System.Windows.Forms.Label();
			this.paperOrientationList = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.paperSizeList = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.printerDuplexList = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.paperSourceList = new System.Windows.Forms.ComboBox();
			this.printReport = new System.Windows.Forms.Button();
			this.message = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.crystalReportViewer.Location = new System.Drawing.Point(0, 152);
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(568, 240);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(96, 23);
			this.label1.TabIndex = 1;
			this.label1.Text = "Paper Orientation";
			
			// 
			// paperOrientationList
			// 
			this.paperOrientationList.Location = new System.Drawing.Point(112, 8);
			this.paperOrientationList.Name = "paperOrientationList";
			this.paperOrientationList.Size = new System.Drawing.Size(121, 21);
			this.paperOrientationList.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 32);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(96, 23);
			this.label2.TabIndex = 3;
			this.label2.Text = "Paper Size";
			// 
			// paperSizeList
			// 
			this.paperSizeList.Location = new System.Drawing.Point(112, 32);
			this.paperSizeList.Name = "paperSizeList";
			this.paperSizeList.Size = new System.Drawing.Size(121, 21);
			this.paperSizeList.TabIndex = 4;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 56);
			this.label3.Name = "label3";
			this.label3.TabIndex = 5;
			this.label3.Text = "Printer Duplex";
			// 
			// printerDuplexList
			// 
			this.printerDuplexList.Location = new System.Drawing.Point(112, 56);
			this.printerDuplexList.Name = "printerDuplexList";
			this.printerDuplexList.Size = new System.Drawing.Size(121, 21);
			this.printerDuplexList.TabIndex = 6;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 80);
			this.label4.Name = "label4";
			this.label4.TabIndex = 7;
			this.label4.Text = "Paper Source";
			// 
			// paperSourceList
			// 
			this.paperSourceList.Location = new System.Drawing.Point(112, 80);
			this.paperSourceList.Name = "paperSourceList";
			this.paperSourceList.Size = new System.Drawing.Size(121, 21);
			this.paperSourceList.TabIndex = 8;
			// 
			// printReport
			// 
			this.printReport.Location = new System.Drawing.Point(8, 112);
			this.printReport.Name = "printReport";
			this.printReport.Size = new System.Drawing.Size(144, 23);
			this.printReport.TabIndex = 9;
			this.printReport.Text = "Print Report From Server";
			this.printReport.Click += new System.EventHandler(this.printReport_Click);
			// 
			// message
			// 
			this.message.Location = new System.Drawing.Point(168, 112);
			this.message.Name = "message";
			this.message.Size = new System.Drawing.Size(120, 23);
			this.message.TabIndex = 10;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(568, 390);
			this.Controls.Add(this.message);
			this.Controls.Add(this.printReport);
			this.Controls.Add(this.paperSourceList);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.printerDuplexList);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.paperSizeList);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.paperOrientationList);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.crystalReportViewer);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void printReport_Click(object sender, System.EventArgs e)
		{
			SetPrintOptions();

			try
			{
				hierarchicalGroupingReport.PrintToPrinter(1, false, 1, 99);
				message.Text = MessageConstants.SUCCESS;
			}
			catch (Exception ex)
			{
				message.Text = MessageConstants.FAILURE + ex.Message;
			}
		}

		
	}
}
