using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace CS_Web_RDObjMod_SetPrintOptions
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
		protected System.Web.UI.WebControls.DropDownList paperOrientationList;
		protected System.Web.UI.WebControls.DropDownList paperSizeList;
		protected System.Web.UI.WebControls.DropDownList printerDuplexList;
		protected System.Web.UI.WebControls.DropDownList paperSourceList;
		protected System.Web.UI.WebControls.Button printReport;
		protected System.Web.UI.WebControls.Label message;
		private Hierarchical_Grouping hierarchicalGroupingReport;
		//private const string CURRENT_PRINTER = @"\\NetworkPrinterServer2\Printer15";
		private const string CURRENT_PRINTER = @"\\VANPRT04\C3-8N-DOC";
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if (!IsPostBack)
			{
				paperOrientationList.DataSource = System.Enum.GetValues(typeof(PaperOrientation));
				paperSizeList.DataSource = System.Enum.GetValues(typeof(PaperSize));
				printerDuplexList.DataSource = System.Enum.GetValues(typeof(PrinterDuplex));
				paperSourceList.DataSource = GetPaperSources();
				DataBind();
			}



		}

		private void ConfigureCrystalReports()
		{
			hierarchicalGroupingReport = new Hierarchical_Grouping();
			crystalReportViewer.ReportSource = hierarchicalGroupingReport;

		}

		private ArrayList GetPaperSources()
		{
			ArrayList arrayList = new ArrayList();
			System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
			printerSettings.PrinterName = CURRENT_PRINTER;

			foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
			{
				arrayList.Add(paperSource.SourceName.ToString());
			}
			return arrayList;
		}

		private System.Drawing.Printing.PaperSource GetSelectedPaperSource()
		{
			System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
			printerSettings.PrinterName = CURRENT_PRINTER;

			System.Drawing.Printing.PaperSource selectedPaperSource = printerSettings.PaperSources[0];
			
			foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
			{
				if (paperSource.SourceName == paperSourceList.SelectedItem.Text)
				{
					selectedPaperSource = paperSource;
				}
			}
			return selectedPaperSource;
		}


		private void SetPrintOptions()
		{
			PrintOptions printOptions = hierarchicalGroupingReport.PrintOptions;
			printOptions.PrinterName = CURRENT_PRINTER;
			printOptions.PaperOrientation = (PaperOrientation)paperOrientationList.SelectedIndex;
			printOptions.PaperSize = (PaperSize)paperSizeList.SelectedIndex;
			printOptions.PrinterDuplex = (PrinterDuplex)printerDuplexList.SelectedIndex;
			printOptions.CustomPaperSource = GetSelectedPaperSource();
		}



		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.printReport.Click += new System.EventHandler(this.printReport_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void printReport_Click(object sender, System.EventArgs e)
		{
			SetPrintOptions();

			try
			{
				hierarchicalGroupingReport.PrintToPrinter(1, false, 1, 99);
				message.Text = MessageConstants.SUCCESS;
			}
			catch (Exception ex)
			{
				message.Text = MessageConstants.FAILURE + ex.Message;
			}
		}
	}
}
