using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace CS_Win_Data_ADONET
{
	/// <summary>
	/// Summary description for DataSetConfiguration.
	/// </summary>
	public class DataSetConfiguration
	{
		private const string CONNECTION_STRING = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Program Files\\Business Objects\\Common\\3.5\\Samples\\En\\Databases\\xtreme.mdb";
		private const string QUERY_STRING = "SELECT * FROM CUSTOMER";
		private const string DATATABLE_NAME = "Customer";

		public static DataSet CustomerDataSet
		{
			get
			{
				CustomerDataSetSchema dataSet = new CustomerDataSetSchema();
				OleDbConnection oleDbConnection = new OleDbConnection(CONNECTION_STRING);
				OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(QUERY_STRING, oleDbConnection);
				oleDbDataAdapter.Fill(dataSet, DATATABLE_NAME);
				return dataSet;
			}
		}
		public DataSetConfiguration()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
