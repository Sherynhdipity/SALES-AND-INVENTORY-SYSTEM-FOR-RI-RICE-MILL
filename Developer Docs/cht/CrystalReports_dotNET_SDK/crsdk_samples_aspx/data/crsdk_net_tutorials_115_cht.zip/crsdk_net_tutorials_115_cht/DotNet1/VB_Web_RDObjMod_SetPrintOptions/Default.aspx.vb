Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Collections

Public Class _Default
    Inherits System.Web.UI.Page
    Protected WithEvents myCrystalReportViewer As CrystalDecisions.Web.CrystalReportViewer

    Private hierarchicalGroupingReport As ReportDocument
    Protected WithEvents paperOrientationList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents paperSizeList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents printerDuplexList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents paperSourceList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents printReport As System.Web.UI.WebControls.Button
    Protected WithEvents message As System.Web.UI.WebControls.Label
    Private Const CURRENT_PRINTER As String = "\\VANPRT04\V3-4TN-RD1"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
        ConfigureCrystalReports()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            paperOrientationList.DataSource = System.Enum.GetValues(GetType(PaperOrientation))
            paperSizeList.DataSource = System.Enum.GetValues(GetType(PaperSize))
            printerDuplexList.DataSource = System.Enum.GetValues(GetType(PrinterDuplex))
            paperSourceList.DataSource = GetPaperSources()
            DataBind()
        End If
    End Sub

    Private Sub ConfigureCrystalReports()
        hierarchicalGroupingReport = New ReportDocument()
        hierarchicalGroupingReport.Load("C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Hierarchical Grouping.rpt")
        myCrystalReportViewer.ReportSource = hierarchicalGroupingReport
    End Sub

    Private Sub printReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printReport.Click
        SetPrintOptions()
        Try
            hierarchicalGroupingReport.PrintToPrinter(1, False, 1, 99)
            message.Text = MessageConstants.SUCCESS
        Catch ex As Exception
            message.Text = MessageConstants.FAILURE & ex.Message
        End Try
    End Sub

    Private Function GetPaperSources() As ArrayList
        Dim myArrayList As ArrayList = New ArrayList()
        Dim myPrinterSettings As System.Drawing.Printing.PrinterSettings = New System.Drawing.Printing.PrinterSettings()
        myPrinterSettings.PrinterName = CURRENT_PRINTER

        Dim myPaperSource As System.Drawing.Printing.PaperSource
        For Each myPaperSource In myPrinterSettings.PaperSources
            myArrayList.Add(myPaperSource.SourceName.ToString())
        Next
        Return myArrayList
    End Function

    Private Function GetSelectedPaperSource() As System.Drawing.Printing.PaperSource
        Dim myPrinterSettings As System.Drawing.Printing.PrinterSettings = New System.Drawing.Printing.PrinterSettings()
        myPrinterSettings.PrinterName = CURRENT_PRINTER
        Dim selectedPaperSource As System.Drawing.Printing.PaperSource = myPrinterSettings.PaperSources(0)

        Dim myPaperSource As System.Drawing.Printing.PaperSource
        For Each myPaperSource In myPrinterSettings.PaperSources
            If myPaperSource.SourceName = paperSourceList.SelectedItem.Text Then
                selectedPaperSource = myPaperSource
            End If
        Next
        Return selectedPaperSource
    End Function

    Private Sub SetPrintOptions()
        Dim myPrintOptions As PrintOptions = hierarchicalGroupingReport.PrintOptions
        myPrintOptions.PrinterName = CURRENT_PRINTER
        myPrintOptions.PaperOrientation = CType(paperOrientationList.SelectedIndex, PaperOrientation)
        myPrintOptions.PaperSize = CType(paperSizeList.SelectedIndex, PaperSize)
        myPrintOptions.PrinterDuplex = CType(printerDuplexList.SelectedIndex, PrinterDuplex)
        myPrintOptions.CustomPaperSource = GetSelectedPaperSource()
    End Sub

End Class
