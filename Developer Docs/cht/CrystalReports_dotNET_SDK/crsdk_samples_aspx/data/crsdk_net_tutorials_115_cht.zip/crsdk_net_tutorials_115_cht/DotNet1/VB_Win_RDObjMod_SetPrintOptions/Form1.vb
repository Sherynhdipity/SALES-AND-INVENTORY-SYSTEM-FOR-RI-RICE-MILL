Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private hierarchicalGroupingReport As Hierarchical_Grouping
    Private Const CURRENT_PRINTER As String = "\\VANRPT04\C3-8N-DOC"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        paperOrientationList.DataSource = System.Enum.GetValues(GetType(PaperOrientation))
        paperSizeList.DataSource = System.Enum.GetValues(GetType(PaperSize))
        printerDuplexList.DataSource = System.Enum.GetValues(GetType(PrinterDuplex))
        paperSourceList.DataSource = GetPaperSources()
        ConfigureCrystalReports()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents paperOrientationList As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents paperSizeList As System.Windows.Forms.ComboBox
    Friend WithEvents printerDuplexList As System.Windows.Forms.ComboBox
    Friend WithEvents paperSourceList As System.Windows.Forms.ComboBox
    Friend WithEvents myCrystalReportViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents printReport As System.Windows.Forms.Button
    Friend WithEvents Message As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.myCrystalReportViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.Label1 = New System.Windows.Forms.Label
        Me.paperOrientationList = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.paperSizeList = New System.Windows.Forms.ComboBox
        Me.printerDuplexList = New System.Windows.Forms.ComboBox
        Me.paperSourceList = New System.Windows.Forms.ComboBox
        Me.printReport = New System.Windows.Forms.Button
        Me.Message = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'myCrystalReportViewer
        '
        Me.myCrystalReportViewer.ActiveViewIndex = -1
        Me.myCrystalReportViewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.myCrystalReportViewer.Location = New System.Drawing.Point(0, 160)
        Me.myCrystalReportViewer.Name = "myCrystalReportViewer"
        Me.myCrystalReportViewer.ReportSource = Nothing
        Me.myCrystalReportViewer.Size = New System.Drawing.Size(584, 256)
        Me.myCrystalReportViewer.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Paper Orientation"
        '
        'paperOrientationList
        '
        Me.paperOrientationList.Location = New System.Drawing.Point(112, 8)
        Me.paperOrientationList.Name = "paperOrientationList"
        Me.paperOrientationList.Size = New System.Drawing.Size(200, 21)
        Me.paperOrientationList.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Paper Size"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Printer Duplex "
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Paper Source"
        '
        'paperSizeList
        '
        Me.paperSizeList.Location = New System.Drawing.Point(112, 32)
        Me.paperSizeList.Name = "paperSizeList"
        Me.paperSizeList.Size = New System.Drawing.Size(200, 21)
        Me.paperSizeList.TabIndex = 6
        '
        'printerDuplexList
        '
        Me.printerDuplexList.Location = New System.Drawing.Point(112, 56)
        Me.printerDuplexList.Name = "printerDuplexList"
        Me.printerDuplexList.Size = New System.Drawing.Size(200, 21)
        Me.printerDuplexList.TabIndex = 7
        '
        'paperSourceList
        '
        Me.paperSourceList.Location = New System.Drawing.Point(112, 80)
        Me.paperSourceList.Name = "paperSourceList"
        Me.paperSourceList.Size = New System.Drawing.Size(200, 21)
        Me.paperSourceList.TabIndex = 8
        '
        'printReport
        '
        Me.printReport.Location = New System.Drawing.Point(8, 120)
        Me.printReport.Name = "printReport"
        Me.printReport.Size = New System.Drawing.Size(168, 23)
        Me.printReport.TabIndex = 9
        Me.printReport.Text = "Print From Server"
        '
        'Message
        '
        Me.Message.Location = New System.Drawing.Point(184, 120)
        Me.Message.Name = "Message"
        Me.Message.Size = New System.Drawing.Size(168, 23)
        Me.Message.TabIndex = 10
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(584, 414)
        Me.Controls.Add(Me.Message)
        Me.Controls.Add(Me.printReport)
        Me.Controls.Add(Me.paperSourceList)
        Me.Controls.Add(Me.printerDuplexList)
        Me.Controls.Add(Me.paperSizeList)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.paperOrientationList)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.myCrystalReportViewer)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ConfigureCrystalReports()
        hierarchicalGroupingReport = New Hierarchical_Grouping
        myCrystalReportViewer.ReportSource = hierarchicalGroupingReport
    End Sub

    Private Function GetPaperSources() As ArrayList
        Dim myArrayList As ArrayList = New ArrayList
        Dim myPrinterSettings As System.Drawing.Printing.PrinterSettings = New System.Drawing.Printing.PrinterSettings
        myPrinterSettings.PrinterName = CURRENT_PRINTER

        Dim myPaperSource As System.Drawing.Printing.PaperSource
        For Each myPaperSource In myPrinterSettings.PaperSources
            myArrayList.Add(myPaperSource.SourceName.ToString())
        Next
        Return myArrayList
    End Function

    Private Function GetSelectedPaperSource() As System.Drawing.Printing.PaperSource
        Dim myPrinterSettings As System.Drawing.Printing.PrinterSettings = New System.Drawing.Printing.PrinterSettings
        myPrinterSettings.PrinterName = CURRENT_PRINTER

        Dim selectedPaperSource As System.Drawing.Printing.PaperSource = myPrinterSettings.PaperSources(0)


        Dim myPaperSource As System.Drawing.Printing.PaperSource
        For Each myPaperSource In myPrinterSettings.PaperSources
            If myPaperSource.SourceName = paperSourceList.SelectedText Then
                selectedPaperSource = myPaperSource
            End If
        Next
        Return selectedPaperSource
    End Function

    Private Sub SetPrintOptions()
        Dim myPrintOptions As PrintOptions = hierarchicalGroupingReport.PrintOptions
        myPrintOptions.PrinterName = CURRENT_PRINTER
        myPrintOptions.PaperOrientation = CType(paperOrientationList.SelectedIndex, PaperOrientation)
        myPrintOptions.PaperSize = CType(paperSizeList.SelectedIndex, PaperSize)
        myPrintOptions.PrinterDuplex = CType(printerDuplexList.SelectedIndex, PrinterDuplex)
        myPrintOptions.CustomPaperSource = GetSelectedPaperSource()
    End Sub


    Private Sub printReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printReport.Click
        Try
            hierarchicalGroupingReport.PrintToPrinter(1, False, 1, 99)
            Message.Text = MessageConstants.SUCCESS
        Catch ex As Exception
            Message.Text = MessageConstants.FAILURE & ex.Message
        End Try
    End Sub
End Class
