using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjMod_Export
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private ReportDocument hierarchicalGroupingReport;
		private string exportPath;
		private DiskFileDestinationOptions diskFileDestinationOptions;
		private ExportOptions exportOptions;
		private bool selectedNoFormat = false;
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		private System.Windows.Forms.ComboBox exportTypesList;
		private System.Windows.Forms.Button exportByType;
		private System.Windows.Forms.Label message;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ConfigureCrystalReports();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		private void ConfigureCrystalReports()
		{
			exportTypesList.DataSource = System.Enum.GetValues(typeof(ExportFormatType));
			hierarchicalGroupingReport = new ReportDocument();
			hierarchicalGroupingReport.Load(@"C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Hierarchical Grouping.rpt");
			crystalReportViewer.ReportSource = hierarchicalGroupingReport;

		}
		private void ExportSetup()
		{
			exportPath = "C:\\Exported\\";
			if (!System.IO.Directory.Exists(exportPath))
			{
				System.IO.Directory.CreateDirectory(exportPath);
			}
			diskFileDestinationOptions = new DiskFileDestinationOptions();
			exportOptions = new ExportOptions();
			exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
			exportOptions.FormatOptions = null;
		}

		private void ExportSelection()
		{
			switch ((ExportFormatType)exportTypesList.SelectedIndex)
			{
				case ExportFormatType.NoFormat:
					selectedNoFormat = true;
					break;
				case ExportFormatType.CharacterSeparatedValues:
					ConfigureExportToCSV();
					break;
                case ExportFormatType.CrystalReport:
					ConfigureExportToRpt();
					break;
				case ExportFormatType.RichText:
					ConfigureExportToRtf();
					break;
				case ExportFormatType.EditableRTF:
					ConfigureExportToEditableRTF();
					break;
				case ExportFormatType.WordForWindows:
					ConfigureExportToDoc();
					break;
				case ExportFormatType.Excel:
					ConfigureExportToXls();
					break;
				case ExportFormatType.PortableDocFormat:
					ConfigureExportToPdf();
					break;
				case ExportFormatType.HTML32:
					ConfigureExportToHtml32();
					break;
				case ExportFormatType.HTML40:
					ConfigureExportToHtml40();
					break;
				case ExportFormatType.ExcelRecord:
					ConfigureExportToXlsRec();
					break;
				case ExportFormatType.Text:
					ConfigureExportToTxt();
					break;
				case ExportFormatType.TabSeperatedText:
					ConfigureExportToTabSeparatedText();
					break;

			}
		}

		private void ExportCompletion()
		{
			try
			{
				if (selectedNoFormat)
				{
					message.Text = MessageConstants.FORMAT_NOT_SUPPORTED;
				}
				else
				{
					hierarchicalGroupingReport.Export(exportOptions);
					message.Text = MessageConstants.SUCCESS;
				}
			}
			catch (Exception ex)
			{
				message.Text = MessageConstants.FAILURE + ex.Message;
			}
			message.Visible = true;
			selectedNoFormat = false;
		}

		
		private void ConfigureExportToCSV()
		{
			exportOptions.ExportFormatType = ExportFormatType.CharacterSeparatedValues;
			diskFileDestinationOptions.DiskFileName = exportPath + "Report.csv";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToRpt()
		{
			exportOptions.ExportFormatType = ExportFormatType.CrystalReport;
			diskFileDestinationOptions.DiskFileName = exportPath + "Report.rpt";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToRtf()
		{
			exportOptions.ExportFormatType = ExportFormatType.RichText;
			diskFileDestinationOptions.DiskFileName = exportPath + "RichTextFormat.rtf";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToEditableRTF()
		{
			exportOptions.ExportFormatType = ExportFormatType.EditableRTF;
			diskFileDestinationOptions.DiskFileName = exportPath + "EditableRichTextFormat.rtf";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToDoc()
		{
			exportOptions.ExportFormatType = ExportFormatType.WordForWindows;
			diskFileDestinationOptions.DiskFileName = exportPath + "Word.doc";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToXls()
		{
			exportOptions.ExportFormatType = ExportFormatType.Excel;
			diskFileDestinationOptions.DiskFileName = exportPath + "Excel.xls";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToPdf()
		{
			exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
			diskFileDestinationOptions.DiskFileName = exportPath + "PortableDoc.pdf";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToHtml32()
		{
			exportOptions.ExportFormatType = ExportFormatType.HTML32;
			HTMLFormatOptions html32FormatOptions = new HTMLFormatOptions();
			html32FormatOptions.HTMLBaseFolderName = exportPath + "Html32Folder";
			html32FormatOptions.HTMLFileName = "html32.html";
			html32FormatOptions.HTMLEnableSeparatedPages = false;
			html32FormatOptions.HTMLHasPageNavigator = false;
			exportOptions.FormatOptions = html32FormatOptions;
		}

		private void ConfigureExportToHtml40()
		{
			exportOptions.ExportFormatType = ExportFormatType.HTML40;
			HTMLFormatOptions html40FormatOptions = new HTMLFormatOptions();
			html40FormatOptions.HTMLBaseFolderName = exportPath + "Html40Folder";
			html40FormatOptions.HTMLFileName = "html40.html";
			html40FormatOptions.HTMLEnableSeparatedPages = true;
			html40FormatOptions.HTMLHasPageNavigator = true;
			html40FormatOptions.FirstPageNumber = 1;
			html40FormatOptions.LastPageNumber = 3;
			exportOptions.FormatOptions = html40FormatOptions;
		}

		private void ConfigureExportToXlsRec()
		{
			exportOptions.ExportFormatType = ExportFormatType.ExcelRecord;
			diskFileDestinationOptions.DiskFileName = exportPath + "ExcelRecord.xls";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToTxt()
		{
			exportOptions.ExportFormatType = ExportFormatType.Text;
			diskFileDestinationOptions.DiskFileName = exportPath + "Text.txt";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}
		
		private void ConfigureExportToTabSeparatedText()
		{
			exportOptions.ExportFormatType = ExportFormatType.TabSeperatedText;
			diskFileDestinationOptions.DiskFileName = exportPath + "TabSeparatedText.txt";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.exportTypesList = new System.Windows.Forms.ComboBox();
			this.exportByType = new System.Windows.Forms.Button();
			this.message = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.crystalReportViewer.Location = new System.Drawing.Point(0, 80);
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(552, 232);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// exportTypesList
			// 
			this.exportTypesList.Location = new System.Drawing.Point(16, 16);
			this.exportTypesList.Name = "exportTypesList";
			this.exportTypesList.Size = new System.Drawing.Size(121, 21);
			this.exportTypesList.TabIndex = 1;
			// 
			// exportByType
			// 
			this.exportByType.Location = new System.Drawing.Point(152, 16);
			this.exportByType.Name = "exportByType";
			this.exportByType.Size = new System.Drawing.Size(144, 23);
			this.exportByType.TabIndex = 2;
			this.exportByType.Text = "Export As Selected Type";
			this.exportByType.Click += new System.EventHandler(this.exportByType_Click);
			// 
			// message
			// 
			this.message.Location = new System.Drawing.Point(304, 16);
			this.message.Name = "message";
			this.message.Size = new System.Drawing.Size(232, 48);
			this.message.TabIndex = 3;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(552, 318);
			this.Controls.Add(this.message);
			this.Controls.Add(this.exportByType);
			this.Controls.Add(this.exportTypesList);
			this.Controls.Add(this.crystalReportViewer);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void exportByType_Click(object sender, System.EventArgs e)
		{
			ExportSetup();
			ExportSelection();
			ExportCompletion();
		}
	}
}
