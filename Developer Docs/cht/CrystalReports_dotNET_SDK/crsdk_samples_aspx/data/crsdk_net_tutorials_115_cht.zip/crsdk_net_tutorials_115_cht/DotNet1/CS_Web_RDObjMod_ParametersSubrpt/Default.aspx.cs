using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Web_RDObjMod_ParametersSubrpt
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
		private CustomersByCity customersByCityReport;
		protected System.Web.UI.WebControls.ListBox defaultParameterValuesList;
		protected System.Web.UI.WebControls.Button redisplay;
		private const string PARAMETER_FIELD_NAME = "City";
		private const string SUBREPORT_PARAMETER_FIELD_NAME = "OrderDateRange";
		protected System.Web.UI.WebControls.TextBox orderStartDate;
		protected System.Web.UI.WebControls.TextBox orderEndDate;
		private const string SUBREPORT_NAME = "CustomerOrders";

	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void ConfigureCrystalReports()
		{
			customersByCityReport = new CustomersByCity();

			ArrayList arrayList = new ArrayList();
			string startDate;
			string endDate;

			if (!IsPostBack)
			{
				defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport);
				defaultParameterValuesList.DataBind();
				arrayList.Add("Paris");
				arrayList.Add("Tokyo");
				Session["arrayList"] = arrayList;
				startDate = "8/1/2004";
				orderStartDate.Text = startDate;
				endDate = "8/31/2004";
				orderEndDate.Text = endDate;
				Session["startDate"] = startDate;
				Session["endDate"] = endDate;
			}
			else
			{
				arrayList = (ArrayList)Session["arrayList"];
				startDate = Session["startDate"].ToString();
				endDate = Session["endDate"].ToString();
				
			}

			SetCurrentValuesForParameterField(customersByCityReport, arrayList);
			SetDateRangeForOrders(customersByCityReport, startDate, endDate);

			crystalReportViewer.ReportSource = customersByCityReport;
		}

		private void SetCurrentValuesForParameterField(ReportDocument reportDocument, ArrayList arrayList)
		{
			ParameterValues currentParameterValues = new ParameterValues();

			foreach (object submittedValue in arrayList)
			{
				ParameterDiscreteValue parameterDiscreteValue = new ParameterDiscreteValue();
				parameterDiscreteValue.Value = submittedValue.ToString();
				currentParameterValues.Add(parameterDiscreteValue);
			}
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;

			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			parameterFieldDefinition.ApplyCurrentValues(currentParameterValues);
		}

		private ArrayList GetDefaultValuesFromParameterField(ReportDocument reportDocument)
		{
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;
			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			ParameterValues defaultParameterValues = parameterFieldDefinition.DefaultValues;

			ArrayList arrayList = new ArrayList();

			foreach (ParameterValue parameterValue in defaultParameterValues)
			{
				if (!parameterValue.IsRange)
				{
					ParameterDiscreteValue parameterDiscreteValue = (ParameterDiscreteValue)parameterValue;
					arrayList.Add(parameterDiscreteValue.Value.ToString());
				}
			}
			return arrayList;

		}

		private void SetDateRangeForOrders(ReportDocument reportDocument, string startDate, string endDate)
		{
			ParameterRangeValue parameterRangeValue = new ParameterRangeValue();
			parameterRangeValue.StartValue = startDate;
			parameterRangeValue.EndValue = endDate;
			parameterRangeValue.LowerBoundType = RangeBoundType.BoundInclusive;
			parameterRangeValue.UpperBoundType = RangeBoundType.BoundInclusive;


			ParameterFields parameterFields = reportDocument.ParameterFields;
			ParameterField parameterField = parameterFields[SUBREPORT_PARAMETER_FIELD_NAME, SUBREPORT_NAME];
			parameterField.CurrentValues.Clear();
			parameterField.CurrentValues.Add(parameterRangeValue);
			//parameterField.CurrentValues.AddRange(startDate, endDate, RangeBoundType.BoundInclusive, RangeBoundType.BoundInclusive);//  
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			ArrayList arrayList = new ArrayList();
			foreach (ListItem item in defaultParameterValuesList.Items)
			{
				if (item.Selected)
				{
					arrayList.Add(item.Value);

				}
			}

			Session["arrayList"] = arrayList;
			Session["startDate"] = orderStartDate.Text;
			Session["endDate"] = orderEndDate.Text;

			ConfigureCrystalReports();
		}
	}
}
