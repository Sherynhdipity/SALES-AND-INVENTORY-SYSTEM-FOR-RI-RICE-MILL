using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Web_RDObjMod_Parameters
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		private CustomersByCity customersByCityReport;
		private const string PARAMETER_FIELD_NAME = "City";
		protected System.Web.UI.WebControls.Button redisplay;
		protected System.Web.UI.WebControls.ListBox defaultParameterValuesList;
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void ConfigureCrystalReports()
		{
			customersByCityReport = new CustomersByCity();

			ArrayList arrayList = new ArrayList();


			if (!IsPostBack)
			{
				defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport);
				defaultParameterValuesList.DataBind();
				arrayList.Add("Paris");
				arrayList.Add("Tokyo");
				Session["arrayList"] = arrayList;
			}
			else
			{
				arrayList = (ArrayList)Session["arrayList"];
			}

			SetCurrentValuesForParameterField(customersByCityReport, arrayList);

			crystalReportViewer.ReportSource = customersByCityReport;
		}

		private void SetCurrentValuesForParameterField(ReportDocument reportDocument, ArrayList arrayList)
		{
			ParameterValues currentParameterValues = new ParameterValues();

			foreach (object submittedValue in arrayList)
			{
				ParameterDiscreteValue parameterDiscreteValue = new ParameterDiscreteValue();
				parameterDiscreteValue.Value = submittedValue.ToString();
				currentParameterValues.Add(parameterDiscreteValue);
			}
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;

			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			parameterFieldDefinition.ApplyCurrentValues(currentParameterValues);
		}

		private ArrayList GetDefaultValuesFromParameterField(ReportDocument reportDocument)
		{
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;
			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			ParameterValues defaultParameterValues = parameterFieldDefinition.DefaultValues;

			ArrayList arrayList = new ArrayList();

			foreach (ParameterValue parameterValue in defaultParameterValues)
			{
				if (!parameterValue.IsRange)
				{
					ParameterDiscreteValue parameterDiscreteValue = (ParameterDiscreteValue)parameterValue;
					arrayList.Add(parameterDiscreteValue.Value.ToString());
				}
			}
			return arrayList;

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			
			ArrayList arrayList = new ArrayList();
			foreach (ListItem item in defaultParameterValuesList.Items)
			{
				if (item.Selected)
				{
					arrayList.Add(item.Value);

				}
			}

			Session["arrayList"] = arrayList;
			ConfigureCrystalReports();
		}
	}
}
