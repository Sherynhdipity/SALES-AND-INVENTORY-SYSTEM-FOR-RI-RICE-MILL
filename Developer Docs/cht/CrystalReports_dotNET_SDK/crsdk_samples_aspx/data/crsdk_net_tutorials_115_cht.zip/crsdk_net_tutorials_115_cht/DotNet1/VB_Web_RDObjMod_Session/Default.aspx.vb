Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class _Default
    Inherits System.Web.UI.Page
    Protected WithEvents sortOrderDescending As System.Web.UI.WebControls.Button
    Protected WithEvents sortOrderAscending As System.Web.UI.WebControls.Button
    Protected WithEvents myCrystalReportViewer As CrystalDecisions.Web.CrystalReportViewer

    Private hierarchicalGroupingReport As Hierarchical_Grouping

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
        ConfigureCrystalReports()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ConfigureCrystalReports()
        If (Session("hierarchicalGroupingReport") Is Nothing) Then
            hierarchicalGroupingReport = New Hierarchical_Grouping()
            Session("hierarchicalGroupingReport") = hierarchicalGroupingReport
        Else
            hierarchicalGroupingReport = CType(Session("hierarchicalGroupingReport"), Hierarchical_Grouping)
        End If

        myCrystalReportViewer.ReportSource = hierarchicalGroupingReport
    End Sub

    Private Sub sortOrderDescending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sortOrderDescending.Click
        Dim mySortFields As SortFields = hierarchicalGroupingReport.DataDefinition.SortFields
        Dim firstSortField As SortField = mySortFields(0)
        firstSortField.SortDirection = SortDirection.DescendingOrder
        Session("hierarchicalGroupingReport") = hierarchicalGroupingReport
        ConfigureCrystalReports()
    End Sub

    Private Sub sortOrderAscending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sortOrderAscending.Click
        Dim mySortFields As SortFields = hierarchicalGroupingReport.DataDefinition.SortFields
        Dim firstSortField As SortField = mySortFields(0)
        firstSortField.SortDirection = SortDirection.AscendingOrder
        Session("hierarchicalGroupingReport") = hierarchicalGroupingReport
        ConfigureCrystalReports()
    End Sub

End Class
