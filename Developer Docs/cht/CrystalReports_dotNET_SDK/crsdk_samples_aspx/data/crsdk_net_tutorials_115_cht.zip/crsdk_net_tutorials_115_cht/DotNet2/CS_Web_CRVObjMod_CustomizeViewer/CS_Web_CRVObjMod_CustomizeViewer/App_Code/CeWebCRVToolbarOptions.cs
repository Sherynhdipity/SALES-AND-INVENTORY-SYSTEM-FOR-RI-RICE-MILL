using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for CeWebCRVToolbarOptions
/// </summary>
public enum CeWebCRVToolbarOptions
{
    Group_Tree_Button,
    Export_Button,
    Print_Button,
    View_List_Button,
    Drill_Up_Button,
    Page_Navigation_Button,
    Go_to_Page_Button,
    Search_Button,
    Zoom_Button,
    Crystal_Logo

}
