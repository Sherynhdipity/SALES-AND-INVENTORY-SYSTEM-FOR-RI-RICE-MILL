Public Enum CeWinCRVReportOptions
    Toolbar
    Group_Tree
    Status_Bar
End Enum
