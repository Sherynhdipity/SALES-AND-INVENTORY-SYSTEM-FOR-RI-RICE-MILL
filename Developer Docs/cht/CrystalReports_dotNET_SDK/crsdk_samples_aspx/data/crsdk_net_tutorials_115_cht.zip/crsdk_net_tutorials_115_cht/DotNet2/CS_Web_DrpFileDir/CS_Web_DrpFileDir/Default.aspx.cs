using System;
using System.Data;
using System.IO;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class _Default : System.Web.UI.Page 
{
	private ReportDocument reportDocument;

	protected void Page_Load(object sender, EventArgs e)
	{
	
	}

	private void Page_Init(object sender, EventArgs e)
	{
		ConfigureCrystalReports();

		if (!IsPostBack)
		{
			string reportPath = Server.MapPath("Reports/");
			string[] reports = Directory.GetFiles(reportPath, "*.rpt");
			IDictionary sortedList = new SortedList();
			foreach (string path in reports)
			{
				int reportNamePrefix = path.LastIndexOf(@"\") + 1;
				int reportNameLength = path.Length - reportNamePrefix;
				string reportName = path.Substring(reportNamePrefix, reportNameLength);
				sortedList.Add(path, reportName);
			}
			reportsList.DataTextField = "value";
			reportsList.DataValueField = "key";
			reportsList.DataSource = sortedList;
			reportsList.DataBind();
		}
		else
		{
			reportDocument = (ReportDocument)Session["reportDocument"];
			crystalReportViewer.ReportSource = reportDocument;
		}
	}


	private void ConfigureCrystalReports()
	{

	}

	protected void display_Click(object sender, EventArgs e)
	{
		reportDocument = new ReportDocument();
		reportDocument.Load(reportsList.SelectedValue);
		Session["reportDocument"] = reportDocument;
		crystalReportViewer.ReportSource = reportDocument;
	}
}
