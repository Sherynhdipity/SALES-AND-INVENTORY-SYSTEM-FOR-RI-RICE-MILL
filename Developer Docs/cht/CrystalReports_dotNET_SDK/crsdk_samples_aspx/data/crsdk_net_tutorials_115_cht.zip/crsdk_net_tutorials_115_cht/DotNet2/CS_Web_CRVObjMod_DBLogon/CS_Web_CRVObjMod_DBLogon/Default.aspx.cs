﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class _Default : System.Web.UI.Page 
{

    private void ConfigureCrystalReports()
    {
        ConnectionInfo connectionInfo = new ConnectionInfo();
        connectionInfo.ServerName = "EN5072738";
        connectionInfo.DatabaseName = "Northwind";
        connectionInfo.UserID = "limitedPermissionAccount";
        connectionInfo.Password = "1234";
        string reportPath = Server.MapPath("NorthwindCustomers.rpt");
        crystalReportViewer.ReportSource = reportPath;
        SetDBLogonForReport(connectionInfo);
    }

    private void Page_Init(object sender, EventArgs e)
    {
        ConfigureCrystalReports();
    }
    private void SetDBLogonForReport(ConnectionInfo connectionInfo)
    {
        TableLogOnInfos tableLogOnInfos = crystalReportViewer.LogOnInfo;
        foreach (TableLogOnInfo tableLogOnInfo in tableLogOnInfos)
        {
            tableLogOnInfo.ConnectionInfo = connectionInfo;
        }
    }
}
