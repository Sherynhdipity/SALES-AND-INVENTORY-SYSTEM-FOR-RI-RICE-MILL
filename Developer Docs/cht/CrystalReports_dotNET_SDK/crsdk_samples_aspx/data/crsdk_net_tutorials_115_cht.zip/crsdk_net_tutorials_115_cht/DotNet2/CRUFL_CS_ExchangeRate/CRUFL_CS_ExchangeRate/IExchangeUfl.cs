using System;
using System.Collections.Generic;
using System.Text;

using System.Runtime.InteropServices;

namespace CRUFL_CS_ExchangeRate
{
	[ComVisible(true), InterfaceType(ComInterfaceType.InterfaceIsDual), Guid("FCD31BA0-6B19-48f0-9FC7-8A90E469282B")]


	public interface IExchangeUfl
	{
		double ConvertUSDollarsToCDN(double usd);
	}

}
