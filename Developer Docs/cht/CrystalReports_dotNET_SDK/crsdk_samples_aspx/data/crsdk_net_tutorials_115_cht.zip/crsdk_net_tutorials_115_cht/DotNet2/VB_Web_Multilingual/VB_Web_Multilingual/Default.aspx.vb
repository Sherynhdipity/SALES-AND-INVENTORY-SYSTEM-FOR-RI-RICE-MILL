Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web

Partial Class _Default
    Inherits System.Web.UI.Page

    Private hierarchicalGroupingReport As ReportDocument

    Private Sub ConfigureCrystalReports()
        hierarchicalGroupingReport = New ReportDocument()
        hierarchicalGroupingReport.Load("C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Hierarchical Grouping.rpt")
        myCrystalReportViewer.ReportSource = hierarchicalGroupingReport
    End Sub



    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        ConfigureCrystalReports()
    End Sub
End Class
