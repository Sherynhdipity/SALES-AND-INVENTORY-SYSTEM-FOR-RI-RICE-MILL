using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.IO;
using System.Collections;

using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

public partial class _Default : System.Web.UI.Page 
{
	private ServerFileReport serverFileReport;
	private ReportManagerRequest reportManagerRequest;
	private ServerFileReportManagerProxy serverFileReportManagerProxy;

    protected void Page_Load(object sender, EventArgs e)
    {
		if (!IsPostBack)
		{
			ArrayList reports = getReports();
			IDictionary sortedList = new SortedList();
			foreach (string path in reports)
			{
				int reportNamePrefix = path.LastIndexOf(@"/") + 1;
				int reportNameSufix = path.LastIndexOf(@"?");
				int reportNameLength = reportNameSufix - reportNamePrefix;
				string reportName = path.Substring(reportNamePrefix, reportNameLength);
				reportName = reportName.Replace("%20", " ");
				sortedList.Add(path, reportName);
			}
			reportsList.DataTextField = "value";
			reportsList.DataValueField = "key";
			reportsList.DataSource = sortedList;
			reportsList.DataBind();
		}
		else
		{
			serverFileReport = (ServerFileReport)Session["serverFileReport"];
			crystalReportViewer.ReportSource = serverFileReport;
		}
    }



	private void Page_Init(object sender, EventArgs e)
	{
		ConfigureCrystalReports();
	}

	private void ConfigureCrystalReports()
	{
	}
	protected void display_Click(object sender, EventArgs e)
	{
		serverFileReport = new ServerFileReport();
		serverFileReport.ReportPath = @"\" + reportsList.SelectedItem.ToString();
		serverFileReport.WebServiceUrl = "http://localhost:80/CrystalReportsWebServices2005/serverfilereportservice.asmx";
		Session["ServerFileReport"] = serverFileReport;
		crystalReportViewer.ReportSource = serverFileReport;
	}

	protected ArrayList getReports()
	{
		serverFileReport = new ServerFileReport();
		serverFileReport.ReportPath = "";
		serverFileReport.WebServiceUrl = "http://localhost:80/CrystalReportsWebServices2005/serverfilereportservice.asmx";
		reportManagerRequest = new ReportManagerRequest();
		reportManagerRequest.ExtraData = serverFileReport.GetExtraData();
		reportManagerRequest.ParentUri = serverFileReport.ToUri();
		serverFileReportManagerProxy = new ServerFileReportManagerProxy();
		serverFileReportManagerProxy.Url = "http://localhost:80/CrystalReportsWebServices2005/serverfilereportmanager.asmx";
		ReportManagerResponse reportManagerResponse = new ReportManagerResponse();
		reportManagerResponse = serverFileReportManagerProxy.ListChildObjects(reportManagerRequest);
		ArrayList remoteReports = new ArrayList();

		foreach (string reportUriString in reportManagerResponse.ReportUris)
		{
			serverFileReport = new ServerFileReport();
			serverFileReport = ServerFileReport.FromUri(reportUriString);
			if (serverFileReport.ObjectType == EnumServerFileType.REPORT)
			{
				remoteReports.Add(reportUriString);
			}
		}
		return remoteReports;
	}
}
