Imports Microsoft.VisualBasic

Public Class Stock
    Private _symbol As String
    Private _volume As Integer
    Private _price As Double

    Sub New()

    End Sub
    Public Property Symbol() As String
        Get
            Return _symbol
        End Get
        Set(ByVal value As String)
            _symbol = value
        End Set
    End Property
    Public Property Price() As Double
        Get
            Return _price
        End Get
        Set(ByVal value As Double)
            _price = value
        End Set
    End Property
    Public Property Volume() As Integer
        Get
            Return _volume
        End Get
        Set(ByVal value As Integer)
            _volume = value
        End Set
    End Property
    Sub New(ByVal s As String, ByVal v As Integer, ByVal p As Double)
        _symbol = symbol
        _volume = volume
        _price = price
    End Sub

End Class
