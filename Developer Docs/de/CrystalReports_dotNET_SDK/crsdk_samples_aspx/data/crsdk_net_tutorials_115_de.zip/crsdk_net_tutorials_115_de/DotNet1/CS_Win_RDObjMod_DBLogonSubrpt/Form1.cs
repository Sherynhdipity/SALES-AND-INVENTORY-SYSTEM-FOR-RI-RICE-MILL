using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjectModel_DBLogonSubreport
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private NorthwindCustomers northwindCustomersReport;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ConfigureCrystalReports();
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(292, 266);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.crystalReportViewer});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void ConfigureCrystalReports()
		{
			northwindCustomersReport = new NorthwindCustomers();

			ConnectionInfo connectionInfo = new ConnectionInfo();
			connectionInfo.ServerName = "HYDROGEN";
			connectionInfo.DatabaseName = "Northwind";
			connectionInfo.UserID = "limitedpermissionsaccount";
			connectionInfo.Password = "1234";

			SetDBLogonForReport(connectionInfo, northwindCustomersReport);
			SetDBLogonForSubreports(connectionInfo, northwindCustomersReport);

			crystalReportViewer.ReportSource = northwindCustomersReport;
		}

		private void SetDBLogonForReport(ConnectionInfo connectionInfo, ReportDocument reportDocument)
		{
			Tables tables = reportDocument.Database.Tables;
			foreach (CrystalDecisions.CrystalReports.Engine.Table table in tables)
			{
				TableLogOnInfo tableLogonInfo = table.LogOnInfo;
				tableLogonInfo.ConnectionInfo = connectionInfo;
				table.ApplyLogOnInfo(tableLogonInfo);
			}
		}

		private void SetDBLogonForSubreports(ConnectionInfo connectionInfo, ReportDocument reportDocument)
		{
			Sections sections = reportDocument.ReportDefinition.Sections;
			foreach (Section section in sections)
			{
				ReportObjects reportObjects = section.ReportObjects;
				foreach (ReportObject reportObject in reportObjects)
				{
					if (reportObject.Kind == ReportObjectKind.SubreportObject)
					{
						SubreportObject subreportObject = (SubreportObject)reportObject;
						ReportDocument subReportDocument = subreportObject.OpenSubreport(subreportObject.SubreportName);
						SetDBLogonForReport(connectionInfo, subReportDocument);
					}
				}
			}
		}
	}
}
