using System;

namespace CS_Web_RDObjMod_FilteringData
{
	/// <summary>
	/// Summary description for CeComparisonOperator
	/// </summary>
	public enum CeComparisonOperator
	{
		EqualTo,
		GreaterThan,
		GreaterThanOrEqualTo,
		LessThan,
		LessThanOrEqualTo,
		NotEqualTo
	}
}
