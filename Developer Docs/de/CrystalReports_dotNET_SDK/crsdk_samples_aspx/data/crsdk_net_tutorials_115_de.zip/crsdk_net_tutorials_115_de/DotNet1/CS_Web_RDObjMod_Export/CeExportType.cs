using System;

namespace CS_Web_RDObjMod_Export
{
	
	/// <summary>
	/// Summary description for CeExportType.
	/// </summary>
	public enum CeExportType
	{
		CSV_CharacterSeparatedValues,
		PDF_PortableDocument,
		RTF_RichTextFormat,
		RTF_EditableRichTextFormat,
		DOC_MicrosoftWord,
		XLS_MicrosoftExcel,
		XLS_ExcelRecord,
		RPT_CrystalReport,
		HTML_Html32,
		HTML_Html40,
		TXT_Text,
		TXT_TabSeparatedText
	}
}
