using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Web_RDObjMod_Export
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
		Hierarchical_Grouping hierarchicalGroupingReport;
		private string exportPath;
		private DiskFileDestinationOptions diskFileDestinationOptions;
		protected System.Web.UI.WebControls.DropDownList exportTypesList;
		protected System.Web.UI.WebControls.Button exportByType;
		protected System.Web.UI.WebControls.Label message;
		private ExportOptions exportOptions;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void ConfigureCrystalReports()
		{
			hierarchicalGroupingReport = new Hierarchical_Grouping();
			crystalReportViewer.ReportSource = hierarchicalGroupingReport;

			if (!IsPostBack)
			{
				exportTypesList.DataSource = System.Enum.GetValues(typeof(CeExportType));
				exportTypesList.DataBind();
			}
		}

		private void exportByType_Click(object sender, System.EventArgs e)
		{
			ExportSetup();
			ExportSelection();
			ExportCompletion();
		}

		private void ExportSetup()
		{
			exportPath = "C:\\Exported\\";
			if (!System.IO.Directory.Exists(exportPath))
			{
				System.IO.Directory.CreateDirectory(exportPath);
			}
			diskFileDestinationOptions = new DiskFileDestinationOptions();
			exportOptions = hierarchicalGroupingReport.ExportOptions;
			exportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
		}

		private void ExportSelection()
		{
			switch ((CeExportType)exportTypesList.SelectedIndex)
			{
				case CeExportType.CSV_CharacterSeparatedValues:
					ConfigureExportToCSV();
					break;
				case CeExportType.DOC_MicrosoftWord:
					ConfigureExportToDoc();
					break;
				case CeExportType.PDF_PortableDocument:
					ConfigureExportToPdf();
					break;
				case CeExportType.RPT_CrystalReport:
					ConfigureExportToRpt();
					break;
				case CeExportType.RTF_RichTextFormat:
					ConfigureExportToRtf();
					break;
				case CeExportType.RTF_EditableRichTextFormat:
					ConfigureExportToEditableRTF();
					break;
				case CeExportType.XLS_MicrosoftExcel:
					ConfigureExportToXls();
					break;
				case CeExportType.XLS_ExcelRecord:
					ConfigureExportToXlsRec();
					break;
				case CeExportType.HTML_Html32:
					ConfigureExportToHtml32();
					break;
				case CeExportType.HTML_Html40:
					ConfigureExportToHtml40();
					break;
				case CeExportType.TXT_Text:
					ConfigureExportToTxt();
					break;
				case CeExportType.TXT_TabSeparatedText:
					ConfigureExportToTabSeparatedText();
					break;
			}
		}

		private void ExportCompletion()
		{
			try
			{
				hierarchicalGroupingReport.Export();
				message.Text = MessageConstants.SUCCESS;
			}
			catch (Exception ex)
			{
				message.Text = MessageConstants.FAILURE + ex.Message;
			}
			message.Visible = true;
		}

		private void ConfigureExportToCSV()
		{
			exportOptions.ExportFormatType = ExportFormatType.CharacterSeparatedValues;
			diskFileDestinationOptions.DiskFileName = exportPath + "Report.csv";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToDoc()
		{
			exportOptions.ExportFormatType = ExportFormatType.WordForWindows;

			diskFileDestinationOptions.DiskFileName = exportPath + "Word.doc";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToPdf()
		{
			exportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;

			diskFileDestinationOptions.DiskFileName = exportPath + "PortableDoc.pdf";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToRpt()
		{
			exportOptions.ExportFormatType = ExportFormatType.CrystalReport;

			diskFileDestinationOptions.DiskFileName = exportPath + "Report.rpt";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToRtf()
		{
			exportOptions.ExportFormatType = ExportFormatType.RichText;

			diskFileDestinationOptions.DiskFileName = exportPath + "RichTextFormat.rtf";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToEditableRTF()
		{
			exportOptions.ExportFormatType = ExportFormatType.EditableRTF;
			diskFileDestinationOptions.DiskFileName = exportPath + "EditableRichTextFormat.rtf";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToXls()
		{
			exportOptions.ExportFormatType = ExportFormatType.Excel;

			diskFileDestinationOptions.DiskFileName = exportPath + "Excel.xls";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToHtml32()
		{
			exportOptions.ExportFormatType = ExportFormatType.HTML32;

			HTMLFormatOptions html32FormatOptions = new HTMLFormatOptions();
			html32FormatOptions.HTMLBaseFolderName = exportPath + "Html32Folder";
			html32FormatOptions.HTMLFileName = "html32.html";
			html32FormatOptions.HTMLEnableSeparatedPages = false;
			html32FormatOptions.HTMLHasPageNavigator = false;

			exportOptions.FormatOptions = html32FormatOptions;
		}

		private void ConfigureExportToHtml40()
		{
			exportOptions.ExportFormatType = ExportFormatType.HTML40;

			HTMLFormatOptions html40FormatOptions = new HTMLFormatOptions();
			html40FormatOptions.HTMLBaseFolderName = exportPath + "Html40Folder";
			html40FormatOptions.HTMLFileName = "html40.html";
			html40FormatOptions.HTMLEnableSeparatedPages = true;
			html40FormatOptions.HTMLHasPageNavigator = true;
			html40FormatOptions.FirstPageNumber = 1;
			html40FormatOptions.LastPageNumber = 3;

			exportOptions.FormatOptions = html40FormatOptions;
		}
		private void ConfigureExportToXlsRec()
		{
			exportOptions.ExportFormatType = ExportFormatType.ExcelRecord;
			diskFileDestinationOptions.DiskFileName = exportPath + "ExcelRecord.xls";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}

		private void ConfigureExportToTxt()
		{
			exportOptions.ExportFormatType = ExportFormatType.Text;
			diskFileDestinationOptions.DiskFileName = exportPath + "Text.txt";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}
		
		private void ConfigureExportToTabSeparatedText()
		{
			exportOptions.ExportFormatType = ExportFormatType.TabSeperatedText;
			diskFileDestinationOptions.DiskFileName = exportPath + "TabSeparatedText.txt";
			exportOptions.DestinationOptions = diskFileDestinationOptions;
		}





		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.exportByType.Click += new System.EventHandler(this.exportByType_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	
	}
}
