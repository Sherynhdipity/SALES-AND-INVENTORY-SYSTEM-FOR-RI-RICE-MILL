using System;

namespace CS_Web_CRVObjMod_CustomizeViewer
{
	/// <summary>
	/// Summary description for CeWebCRVToolbarOptions
	/// </summary>
	public enum CeWebCRVToolbarOptions
	{
		Group_Tree,
		Export,
		Print,
		View_List,
		Drill_Up,
		Page_Navigation,
		Go_to_Page,
		Search,
		Zoom,
		Crystal_Logo
	}
}
