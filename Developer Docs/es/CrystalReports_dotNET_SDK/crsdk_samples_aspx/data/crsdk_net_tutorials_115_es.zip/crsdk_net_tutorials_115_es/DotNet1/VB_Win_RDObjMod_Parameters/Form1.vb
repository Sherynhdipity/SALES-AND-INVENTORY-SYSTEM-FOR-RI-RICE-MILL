Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private customersByCityReport As CustomersByCity
    Private Const PARAMETER_FIELD_NAME As String = "City"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        ConfigureCrystalReports()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents myCrystalReportViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents defaultParameterValuesList As System.Windows.Forms.ListBox
    Friend WithEvents redisplay As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.myCrystalReportViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.defaultParameterValuesList = New System.Windows.Forms.ListBox()
        Me.redisplay = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'myCrystalReportViewer
        '
        Me.myCrystalReportViewer.ActiveViewIndex = -1
        Me.myCrystalReportViewer.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.myCrystalReportViewer.Location = New System.Drawing.Point(0, 134)
        Me.myCrystalReportViewer.Name = "myCrystalReportViewer"
        Me.myCrystalReportViewer.ReportSource = Nothing
        Me.myCrystalReportViewer.Size = New System.Drawing.Size(608, 352)
        Me.myCrystalReportViewer.TabIndex = 0
        '
        'defaultParameterValuesList
        '
        Me.defaultParameterValuesList.Location = New System.Drawing.Point(8, 8)
        Me.defaultParameterValuesList.Name = "defaultParameterValuesList"
        Me.defaultParameterValuesList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.defaultParameterValuesList.Size = New System.Drawing.Size(128, 108)
        Me.defaultParameterValuesList.TabIndex = 1
        '
        'redisplay
        '
        Me.redisplay.Location = New System.Drawing.Point(160, 96)
        Me.redisplay.Name = "redisplay"
        Me.redisplay.Size = New System.Drawing.Size(160, 23)
        Me.redisplay.TabIndex = 2
        Me.redisplay.Text = "Redisplay Report"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(608, 486)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.redisplay, Me.defaultParameterValuesList, Me.myCrystalReportViewer})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ConfigureCrystalReports()
        customersByCityReport = New CustomersByCity()

        Dim myArrayList As ArrayList = New ArrayList()
        myArrayList.Add("Paris")
        myArrayList.Add("Tokyo")

        defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport)

        SetCurrentValuesForParameterField(customersByCityReport, myArrayList)

        myCrystalReportViewer.ReportSource = customersByCityReport
    End Sub

    Private Sub SetCurrentValuesForParameterField(ByVal myReportDocument As ReportDocument, ByVal myArrayList As ArrayList)
        Dim currentParameterValues As ParameterValues = New ParameterValues()
        Dim submittedValue As Object
        For Each submittedValue In myArrayList
            Dim myParameterDiscreteValue As ParameterDiscreteValue = New ParameterDiscreteValue()
            myParameterDiscreteValue.Value = submittedValue.ToString()
            currentParameterValues.Add(myParameterDiscreteValue)
        Next

        Dim myParameterFieldDefinitions As ParameterFieldDefinitions = myReportDocument.DataDefinition.ParameterFields
        Dim myParameterFieldDefinition As ParameterFieldDefinition = myParameterFieldDefinitions(PARAMETER_FIELD_NAME)
        myParameterFieldDefinition.ApplyCurrentValues(currentParameterValues)
    End Sub

    Private Function GetDefaultValuesFromParameterField(ByVal myReportDocument As ReportDocument) As ArrayList
        Dim myParameterFieldDefinitions As ParameterFieldDefinitions = myReportDocument.DataDefinition.ParameterFields
        Dim myParameterFieldDefinition As ParameterFieldDefinition = myParameterFieldDefinitions(PARAMETER_FIELD_NAME)
        Dim defaultParameterValues As ParameterValues = myParameterFieldDefinition.DefaultValues

        Dim myArrayList As ArrayList = New ArrayList()

        Dim myParameterValue As ParameterValue
        For Each myParameterValue In defaultParameterValues
            If (Not myParameterValue.IsRange) Then
                Dim myParameterDiscreteValue As ParameterDiscreteValue = CType(myParameterValue, ParameterDiscreteValue)
                myArrayList.Add(myParameterDiscreteValue.Value.ToString())
            End If
        Next
        Return myArrayList
    End Function

    Private Sub redisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redisplay.Click
        Dim myArrayList As ArrayList = New ArrayList()

        Dim item As String
        For Each item In defaultParameterValuesList.SelectedItems
            myArrayList.Add(item)
        Next

        SetCurrentValuesForParameterField(customersByCityReport, myArrayList)
        myCrystalReportViewer.ReportSource = customersByCityReport
    End Sub
End Class
