﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("CS_Win_Data_IDataReader")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Business Objects")]
[assembly: AssemblyProduct("CS_Win_Data_IDataReader")]
[assembly: AssemblyCopyright("Copyright © Business Objects 2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: ComVisible(false)]

[assembly: Guid("ae2df722-dfac-4d20-a2db-43be4f52fd1c")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
