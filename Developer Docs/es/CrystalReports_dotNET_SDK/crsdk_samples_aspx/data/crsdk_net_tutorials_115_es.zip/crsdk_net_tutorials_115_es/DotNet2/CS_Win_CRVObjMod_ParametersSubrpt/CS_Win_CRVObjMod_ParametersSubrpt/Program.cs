﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CS_Win_CRVObjMod_ParametersSubrpt
{
    static class Program
    {

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Form1());
        }
    }
}