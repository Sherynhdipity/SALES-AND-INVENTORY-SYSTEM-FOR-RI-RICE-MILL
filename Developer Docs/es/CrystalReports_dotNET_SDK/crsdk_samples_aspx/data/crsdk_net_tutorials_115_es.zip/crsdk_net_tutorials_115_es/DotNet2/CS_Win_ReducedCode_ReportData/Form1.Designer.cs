namespace CS_Win_ReducedCode_ReportData
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.drillLabel = new System.Windows.Forms.Label();
            this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // drillLabel
            // 
            this.drillLabel.AutoSize = true;
            this.drillLabel.Location = new System.Drawing.Point(13, 13);
            this.drillLabel.Name = "drillLabel";
            this.drillLabel.Size = new System.Drawing.Size(35, 13);
            this.drillLabel.TabIndex = 0;
            this.drillLabel.Text = "label1";
            // 
            // crystalReportViewer
            // 
            this.crystalReportViewer.ActiveViewIndex = 0;
            this.crystalReportViewer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer.Location = new System.Drawing.Point(16, 30);
            this.crystalReportViewer.Name = "crystalReportViewer";
            this.crystalReportViewer.ReportSource = "C:\\Program Files\\Business Objects\\Crystal Reports 11.5\\Samples\\en\\Reports\\General" +
                " Business\\World Sales Report.rpt";
            this.crystalReportViewer.Size = new System.Drawing.Size(1046, 552);
            this.crystalReportViewer.TabIndex = 1;
            this.crystalReportViewer.Drill += new CrystalDecisions.Windows.Forms.DrillEventHandler(this.crystalReportViewer_Drill);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 594);
            this.Controls.Add(this.crystalReportViewer);
            this.Controls.Add(this.drillLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label drillLabel;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
    }
}

