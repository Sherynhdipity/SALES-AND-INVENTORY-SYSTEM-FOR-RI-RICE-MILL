﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Collections

Partial Class _Default
    Inherits System.Web.UI.Page
    Private Const CURRENT_PRINTER As String = "\\vanprt04\C3-8N-DOC"
    Private hierarchicalGroupingReport As ReportDocument


    Private Sub ConfigureCrystalReports()
        hierarchicalGroupingReport = New ReportDocument()
        hierarchicalGroupingReport.Load("C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Hierarchical Grouping.rpt")
        myCrystalReportViewer.ReportSource = hierarchicalGroupingReport
    End Sub

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        ConfigureCrystalReports()

    End Sub

    Private Function GetPaperSources() As ArrayList
        Dim myArrayList As ArrayList = New ArrayList()
        Dim myPrinterSettings As System.Drawing.Printing.PrinterSettings = New System.Drawing.Printing.PrinterSettings()
        myPrinterSettings.PrinterName = CURRENT_PRINTER
        'Dim myPaperSource As System.Drawing.Printing.PaperSource
        For Each myPaperSource As System.Drawing.Printing.PaperSource In myPrinterSettings.PaperSources
            myArrayList.Add(myPaperSource.SourceName.ToString())
        Next
        Return myArrayList
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            paperOrientationList.DataSource = System.Enum.GetValues(GetType(PaperOrientation))
            paperSizeList.DataSource = System.Enum.GetValues(GetType(PaperSize))
            printerDuplexList.DataSource = System.Enum.GetValues(GetType(PrinterDuplex))
            paperSourceList.DataSource = GetPaperSources()
            DataBind()
        End If
    End Sub

    Private Function GetSelectedPaperSource() As System.Drawing.Printing.PaperSource
        Dim selectedPaperSource As System.Drawing.Printing.PaperSource = New System.Drawing.Printing.PaperSource
        Dim myPrinterSettings As System.Drawing.Printing.PrinterSettings = New System.Drawing.Printing.PrinterSettings()
        myPrinterSettings.PrinterName = CURRENT_PRINTER
        For Each myPaperSource As System.Drawing.Printing.PaperSource In myPrinterSettings.PaperSources
            If myPaperSource.SourceName = paperSourceList.SelectedItem.Text Then
                selectedPaperSource = myPaperSource
            End If
        Next
        Return selectedPaperSource

    End Function

    Private Sub SetPrintOptions()
        Dim myPrintOptions As PrintOptions = hierarchicalGroupingReport.PrintOptions
        myPrintOptions.PrinterName = CURRENT_PRINTER
        myPrintOptions.PaperOrientation = CType(paperOrientationList.SelectedIndex, PaperOrientation)
        myPrintOptions.PaperSize = CType(paperSizeList.SelectedIndex, PaperSize)
        myPrintOptions.PrinterDuplex = CType(printerDuplexList.SelectedIndex, PrinterDuplex)
        myPrintOptions.CustomPaperSource = GetSelectedPaperSource()

    End Sub

    Protected Sub printReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles printReport.Click
        SetPrintOptions()
        Try
            hierarchicalGroupingReport.PrintToPrinter(1, False, 1, 99)
            message.Text = MessageConstants.SUCCESS
        Catch ex As Exception
            message.Text = MessageConstants.FAILURE & ex.Message
        End Try

    End Sub
End Class
