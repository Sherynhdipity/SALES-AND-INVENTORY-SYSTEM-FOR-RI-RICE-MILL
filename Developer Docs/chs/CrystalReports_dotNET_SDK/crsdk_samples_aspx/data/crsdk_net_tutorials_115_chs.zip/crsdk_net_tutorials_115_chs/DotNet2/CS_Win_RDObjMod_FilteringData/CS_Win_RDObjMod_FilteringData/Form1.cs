﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjMod_FilteringData
{
    public partial class Form1 : Form
    {
        private ReportDocument customerBySalesNameReport;
        private string salesAmount;
        private string operatorValue;
        private string customerName;
        private bool useDefaultValues = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void ConfigureCrystalReports()
        {
            customerBySalesNameReport = new ReportDocument();
            string reportPath = Application.StartupPath + "\\" + "CustomerBySalesName.rpt";
            customerBySalesNameReport.Load(reportPath);

            if (useDefaultValues)
            {
                salesAmount = "11000";
                operatorValue = "=";
                customerName = "A";

                operatorValueList.DataSource = System.Enum.GetValues(typeof(CeComparisonOperator));
            }
            string selectionFormula = "{Customer.Last Year's Sales} > "
                + salesAmount
                + " AND Mid({Customer.Customer Name}, 1, 1) "
                + operatorValue
                + "'"
                + customerName
                + "'";

            customerBySalesNameReport.DataDefinition.RecordSelectionFormula = selectionFormula;
            crystalReportViewer.ReportSource = customerBySalesNameReport;

            formula.Text = selectionFormula;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ConfigureCrystalReports();
        }

        private void crystalReportViewer_Load(object sender, EventArgs e)
        {

        }

        private string GetSelectedOperator()
        {
            string selectedOperator = "";
            switch ((CeComparisonOperator)operatorValueList.SelectedIndex)
            {
                case CeComparisonOperator.EqualTo:
                    selectedOperator = "=";
                    break;
                case CeComparisonOperator.GreaterThan:
                    selectedOperator = ">";
                    break;
                case CeComparisonOperator.GreaterThanOrEqualTo:
                    selectedOperator = ">=";
                    break;
                case CeComparisonOperator.LessThan:
                    selectedOperator = "<";
                    break;
                case CeComparisonOperator.LessThanOrEqualTo:
                    selectedOperator = "<=";
                    break;
                case CeComparisonOperator.NotEqualTo:
                    selectedOperator = "<>";
                    break;
            }
            return selectedOperator;
        }

        private void redisplay_Click(object sender, EventArgs e)
        {
            salesAmount = lastYearsSales.Text;
            operatorValue = GetSelectedOperator();
            customerName = letterOfName.Text;
            useDefaultValues = false;
            ConfigureCrystalReports();
        }

    }
}