using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CS_Web_RDObjMod_FilteringData
{
	/// <summary>
	/// Summary description for _Default.
	/// </summary>
	public class _Default : System.Web.UI.Page
	{
		
		private CustomerBySalesName customerBySalesNameReport;
		private string salesAmount;
		private string operatorValue;
		private string customerName;

		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox lastYearsSales;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.DropDownList operatorValueList;
		protected System.Web.UI.WebControls.TextBox name;
		protected System.Web.UI.WebControls.Button redisplay;
		protected System.Web.UI.WebControls.Label formula;
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void ConfigureCrystalReports()
		{
			if (!IsPostBack)
			{
				salesAmount = "11000";
				operatorValue = "=";
				customerName = "A";
				operatorValueList.DataSource = System.Enum.GetValues(typeof(CeComparisonOperator));
				operatorValueList.DataBind();
			}

			string selectionFormula = "{Customer.Last Year's Sales} > "
				+ salesAmount
				+ " AND Mid({Customer.Customer Name}, 1, 1) "
				+ operatorValue
				+ "'"
				+ customerName
				+ "'";

			customerBySalesNameReport = new CustomerBySalesName();
			customerBySalesNameReport.Load(Server.MapPath("CustomerBySalesName.rpt"));
			customerBySalesNameReport.DataDefinition.RecordSelectionFormula = selectionFormula;
			crystalReportViewer.ReportSource = customerBySalesNameReport;
			formula.Text = selectionFormula;
		}

		private string GetSelectedOperator()
		{
			string selectedOperator = "";

			switch ((CeComparisonOperator)operatorValueList.SelectedIndex)
			{
				case CeComparisonOperator.EqualTo:
					selectedOperator = "=";
					break;
				case CeComparisonOperator.GreaterThan:
					selectedOperator = ">";
					break;
				case CeComparisonOperator.GreaterThanOrEqualTo:
					selectedOperator = ">=";
					break;
				case CeComparisonOperator.LessThan:
					selectedOperator = "<";
					break;
				case CeComparisonOperator.LessThanOrEqualTo:
					selectedOperator = "<=";
					break;
				case CeComparisonOperator.NotEqualTo:
					selectedOperator = "<>";
					break;
			}

			return selectedOperator;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			salesAmount = lastYearsSales.Text;
			operatorValue = GetSelectedOperator();
			customerName = name.Text;

			ConfigureCrystalReports();
		}
	}
}
