Public Enum CeComparisonOperator
    EqualTo
    LessThan
    GreaterThan
    LessThan_or_EqualTo
    GreaterThan_or_EqualTo
    Not_EqualTo
End Enum
