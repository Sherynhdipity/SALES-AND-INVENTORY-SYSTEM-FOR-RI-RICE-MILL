﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.IO
Imports System.Collections



Partial Class _Default
    Inherits System.Web.UI.Page
    Private myServerFileReport As ServerFileReport
    Private myReportManagerRequest As ReportManagerRequest
    Private myServerFileReportManagerProxy As ServerFileReportManagerProxy

    Private Sub ConfigureCrystalReports()

    End Sub


    Protected Function getReports() As ArrayList
        myServerFileReport = New ServerFileReport()
        myServerFileReport.ReportPath = ""
        myServerFileReport.WebServiceUrl = "http://localhost:80/CrystalReportsWebServices2005/serverfilereportservice.asmx"
        myReportManagerRequest = New ReportManagerRequest()
        myReportManagerRequest.ExtraData = myServerFileReport.GetExtraData()
        myReportManagerRequest.ParentUri = myServerFileReport.ToUri()
        myServerFileReportManagerProxy = New ServerFileReportManagerProxy()
        myServerFileReportManagerProxy.Url = "http://localhost:80/CrystalReportsWebServices2005/serverfilereportmanager.asmx"
        Dim myReportManagerResponse As ReportManagerResponse = New ReportManagerResponse()
        myReportManagerResponse = myServerFileReportManagerProxy.ListChildObjects(myReportManagerRequest)
        Dim myRemoteReports As ArrayList = New ArrayList()
        For Each myReportUriString As String In myReportManagerResponse.ReportUris
            myServerFileReport = New ServerFileReport()
            myServerFileReport = ServerFileReport.FromUri(myReportUriString)
            If (myServerFileReport.ObjectType = EnumServerFileType.REPORT) Then
                myRemoteReports.Add(myReportUriString)
            End If
        Next
        Return myRemoteReports
    End Function


    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        ConfigureCrystalReports()
        If Not IsPostBack Then
            Dim myReports As ArrayList = getReports()
            Dim mySortedList As IDictionary = New SortedList
            For Each myPath As String In myReports
                Dim myReportNamePrefix As Integer = myPath.LastIndexOf("/") + 1
                Dim myReportNameSufix As Integer = myPath.LastIndexOf("?")
                Dim myReportNameLength As Integer = myReportNameSufix - myReportNamePrefix
                Dim myReportName As String = myPath.Substring(myReportNamePrefix, myReportNameLength)
                myReportName = myReportName.Replace("%20", " ")
                mySortedList.Add(myPath, myReportName)

            Next
            reportsList.DataTextField = "value"
            reportsList.DataValueField = "key"
            reportsList.DataSource = mySortedList
            reportsList.DataBind()

        Else
            myServerFileReport = CType(Session("myServerFileReport"), ServerFileReport)
            myCrystalReportViewer.ReportSource = myServerFileReport

        End If


    End Sub

    Protected Sub display_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles display.Click

        Dim myServerFileReport As ServerFileReport = New ServerFileReport
        myServerFileReport.ReportPath = "\" + reportsList.SelectedItem.ToString
        myServerFileReport.WebServiceUrl = "http://localhost:80/CrystalReportsWebServices2005/serverfilereportservice.asmx"
        Session("ServerFileReport") = myServerFileReport
        myCrystalReportViewer.ReportSource = myServerFileReport

    End Sub
End Class
