using System;
using System.Collections.Generic;
using System.Text;

namespace CS_Win_CRVObjMod_FilteringData
{
    enum CeComparisonOperator
    {
        EqualTo,
        LessThan,
        GreaterThan,
        LessThan_or_EqualTo,
        GreaterThan_or_EqualTo,
        Not_EqualTo
    }
}
