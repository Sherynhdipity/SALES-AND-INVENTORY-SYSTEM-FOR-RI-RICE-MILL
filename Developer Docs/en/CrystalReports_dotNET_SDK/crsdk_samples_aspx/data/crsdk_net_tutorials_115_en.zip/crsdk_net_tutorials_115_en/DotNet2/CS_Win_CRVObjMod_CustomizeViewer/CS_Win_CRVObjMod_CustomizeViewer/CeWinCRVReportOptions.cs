using System;
using System.Collections.Generic;
using System.Text;

namespace CS_Win_CRVObjMod_CustomizeViewer
{
    enum CeWinCRVReportOptions
    {
        Toolbar,
        Group_Tree,
        Status_Bar
    }
}
