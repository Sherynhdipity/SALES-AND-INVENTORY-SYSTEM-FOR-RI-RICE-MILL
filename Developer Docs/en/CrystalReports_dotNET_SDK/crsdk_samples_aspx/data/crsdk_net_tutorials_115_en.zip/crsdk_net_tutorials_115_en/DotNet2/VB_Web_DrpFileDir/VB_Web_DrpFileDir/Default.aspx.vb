
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.IO
Imports System.Collections

Partial Class _Default
    Inherits System.Web.UI.Page

    Private myReportDocument As ReportDocument

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        ConfigureCrystalReports()

        If Not IsPostBack Then
            Dim myReportPath As String = Server.MapPath("Reports/")
            Dim reports() As String = Directory.GetFiles(myReportPath, "*.rpt")
            Dim mySortedList As IDictionary = New SortedList
            For Each path As String In reports
                Dim reportNamePrefix As Integer = path.LastIndexOf("\") + 1
                Dim reportNameLength As Integer = path.Length - reportNamePrefix
                Dim reportName As String = path.Substring(reportNamePrefix, reportNameLength)
                mySortedList.Add(path, reportName)
            Next

            reportsList.DataTextField = "value"
            reportsList.DataValueField = "key"
            reportsList.DataSource = mySortedList
            reportsList.DataBind()
        Else
            myReportDocument = CType(Session("reportDocument"), ReportDocument)
            myCrystalReportViewer.ReportSource = myReportDocument
        End If
    End Sub



    Private Sub ConfigureCrystalReports()

    End Sub


    Protected Sub display_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles display.Click
        myReportDocument = New ReportDocument
        myReportDocument.Load(reportsList.SelectedValue)
        Session("reportDocument") = myReportDocument
        myCrystalReportViewer.ReportSource = myReportDocument
    End Sub


End Class
