Imports Microsoft.VisualBasic

Public Enum CeWebCRVToolbarOptions
    Group_Tree
    Export
    Print
    View_List
    Drill_Up
    Page_Navigation
    Go_to_Page
    Search
    Zoom
    Crystal_Logo
End Enum
