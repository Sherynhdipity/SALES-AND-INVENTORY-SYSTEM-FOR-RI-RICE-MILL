Public Class MessageConstants
    Public Const SUCCESS As String = "The action was successful."
    Public Const FAILURE As String = "The action was not successful: "
    Public Const NOT_ALLOWED As String = "You are not allowed to do this action."
    Public Const FORMAT_NOT_SUPPORTED As String = "That format is not supported."
    Public Const NO_MATCHES_FOUND As String = "No matches were found for the value submitted."
End Class
