using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjectModel_ParametersSubreport
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.ListBox defaultParameterValuesList;
		private CustomersByCity customersByCityReport;
		private System.Windows.Forms.Button redisplay;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox orderEndDate;
		private System.Windows.Forms.TextBox orderStartDate;
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		private const string PARAMETER_FIELD_NAME = "City";
		private const string SUBREPORT_PARAMETER_FIELD_NAME = "OrderDateRange";
		private const string SUBREPORT_NAME = "CustomerOrders";

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ConfigureCrystalReports();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.defaultParameterValuesList = new System.Windows.Forms.ListBox();
			this.redisplay = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.orderEndDate = new System.Windows.Forms.TextBox();
			this.orderStartDate = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.crystalReportViewer.Location = new System.Drawing.Point(0, 110);
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(600, 368);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// defaultParameterValuesList
			// 
			this.defaultParameterValuesList.Location = new System.Drawing.Point(8, 8);
			this.defaultParameterValuesList.Name = "defaultParameterValuesList";
			this.defaultParameterValuesList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.defaultParameterValuesList.Size = new System.Drawing.Size(120, 95);
			this.defaultParameterValuesList.TabIndex = 1;
			// 
			// redisplay
			// 
			this.redisplay.Location = new System.Drawing.Point(152, 80);
			this.redisplay.Name = "redisplay";
			this.redisplay.Size = new System.Drawing.Size(176, 23);
			this.redisplay.TabIndex = 2;
			this.redisplay.Text = "Redisplay Report";
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(160, 16);
			this.label1.Name = "label1";
			this.label1.TabIndex = 3;
			this.label1.Text = "Order Start Date";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(160, 48);
			this.label2.Name = "label2";
			this.label2.TabIndex = 4;
			this.label2.Text = "Order End Date";
			// 
			// orderEndDate
			// 
			this.orderEndDate.Location = new System.Drawing.Point(288, 48);
			this.orderEndDate.Name = "orderEndDate";
			this.orderEndDate.TabIndex = 6;
			this.orderEndDate.Text = "";
			// 
			// orderStartDate
			// 
			this.orderStartDate.Location = new System.Drawing.Point(288, 16);
			this.orderStartDate.Name = "orderStartDate";
			this.orderStartDate.TabIndex = 7;
			this.orderStartDate.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(600, 478);
			this.Controls.Add(this.orderStartDate);
			this.Controls.Add(this.orderEndDate);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.redisplay);
			this.Controls.Add(this.defaultParameterValuesList);
			this.Controls.Add(this.crystalReportViewer);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void ConfigureCrystalReports()
		{
			customersByCityReport = new CustomersByCity();

			ArrayList arrayList = new ArrayList();
			arrayList.Add("Paris");
			arrayList.Add("Tokyo");
			string startDate = "8/1/2004";
			orderStartDate.Text = startDate;
			
			string endDate = "8/31/2004";
			orderEndDate.Text = endDate;

			defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport);

			SetCurrentValuesForParameterField(customersByCityReport, arrayList);
			SetDateRangeForOrders(customersByCityReport, startDate, endDate);

			crystalReportViewer.ReportSource = customersByCityReport;
		}

		private void SetCurrentValuesForParameterField(ReportDocument reportDocument, ArrayList arrayList)
		{
			ParameterValues currentParameterValues = new ParameterValues();
			foreach (object submittedValue in arrayList)
			{
				ParameterDiscreteValue parameterDiscreteValue = new ParameterDiscreteValue();
				parameterDiscreteValue.Value = submittedValue.ToString();
				currentParameterValues.Add(parameterDiscreteValue);
			}
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;
			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			parameterFieldDefinition.ApplyCurrentValues(currentParameterValues);
		}

		private ArrayList GetDefaultValuesFromParameterField(ReportDocument reportDocument)
		{
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;
			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			ParameterValues defaultParameterValues = parameterFieldDefinition.DefaultValues;

			ArrayList arrayList = new ArrayList();

			foreach (ParameterValue parameterValue in defaultParameterValues)
			{
				if (!parameterValue.IsRange)
				{
					ParameterDiscreteValue parameterDiscreteValue = (ParameterDiscreteValue)parameterValue;
					arrayList.Add(parameterDiscreteValue.Value.ToString());
				}
			}
			return arrayList;
		}

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			ArrayList arrayList = new ArrayList();
			foreach (string item in defaultParameterValuesList.SelectedItems)
			{
				arrayList.Add(item);
			}
			SetCurrentValuesForParameterField(customersByCityReport, arrayList);

			string startDate = orderStartDate.Text;
			string endDate = orderEndDate.Text;
			SetDateRangeForOrders(customersByCityReport, startDate, endDate);

			crystalReportViewer.ReportSource = customersByCityReport;
		}

		private void SetDateRangeForOrders(ReportDocument reportDocument, string startDate, string endDate)
		{
			ParameterRangeValue parameterRangeValue = new ParameterRangeValue();
			parameterRangeValue.StartValue = startDate;
			parameterRangeValue.EndValue = endDate;
			parameterRangeValue.LowerBoundType = RangeBoundType.BoundInclusive;
			parameterRangeValue.UpperBoundType = RangeBoundType.BoundInclusive;

			ParameterFields parameterFields = reportDocument.ParameterFields;
			ParameterField parameterField = parameterFields[SUBREPORT_PARAMETER_FIELD_NAME, SUBREPORT_NAME];
			parameterField.CurrentValues.Clear();
			parameterField.CurrentValues.Add(parameterRangeValue);
		}

	}
}
