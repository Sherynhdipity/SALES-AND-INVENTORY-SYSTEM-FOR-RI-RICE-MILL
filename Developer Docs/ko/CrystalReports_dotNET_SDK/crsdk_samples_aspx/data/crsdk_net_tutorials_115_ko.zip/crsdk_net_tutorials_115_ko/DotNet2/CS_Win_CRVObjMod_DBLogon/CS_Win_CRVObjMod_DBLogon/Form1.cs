﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Base
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ConfigureCrystalReports()
        {
            ConnectionInfo connectionInfo = new ConnectionInfo();
            connectionInfo.ServerName = "EN5072738";
            connectionInfo.DatabaseName = "Northwind";
            connectionInfo.UserID = "limitedPermissionAccount";
            connectionInfo.Password = "1234";
            string reportPath = Application.StartupPath + "\\" + "NorthwindCustomers.rpt";
            crystalReportViewer.ReportSource = reportPath;
            SetDBLogonForReport(connectionInfo);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ConfigureCrystalReports();
        }

        private void crystalReportViewer_Load(object sender, EventArgs e)
        {

        }

        private void SetDBLogonForReport(ConnectionInfo connectionInfo)
        {
            TableLogOnInfos tableLogOnInfos = crystalReportViewer.LogOnInfo;
            foreach (TableLogOnInfo tableLogOnInfo in tableLogOnInfos)
            {
                tableLogOnInfo.ConnectionInfo = connectionInfo;

            }

        }
    }
}