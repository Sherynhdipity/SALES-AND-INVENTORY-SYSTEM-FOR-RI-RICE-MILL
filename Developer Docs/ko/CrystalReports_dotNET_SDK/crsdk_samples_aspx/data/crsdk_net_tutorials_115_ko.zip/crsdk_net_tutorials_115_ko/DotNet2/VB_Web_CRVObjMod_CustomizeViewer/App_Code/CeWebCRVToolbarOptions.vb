Imports Microsoft.VisualBasic

Public Enum CeWebCRVToolbarOptions
    Group_Tree_Button
    Export_Button
    Print_Button
    View_List_Button
    Drill_Up_Button
    Page_Navigation_Button
    Go_to_Page_Button
    Search_Button
    Zoom_Button
    Crystal_Logo
End Enum
