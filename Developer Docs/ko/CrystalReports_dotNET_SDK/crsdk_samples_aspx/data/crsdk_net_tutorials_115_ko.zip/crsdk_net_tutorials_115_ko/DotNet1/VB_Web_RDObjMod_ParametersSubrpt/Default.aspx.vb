Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class _Default
    Inherits System.Web.UI.Page
    Protected WithEvents myCrystalReportViewer As CrystalDecisions.Web.CrystalReportViewer
    Protected WithEvents redisplay As System.Web.UI.WebControls.Button
    Protected WithEvents orderEndDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents orderStartDate As System.Web.UI.WebControls.TextBox
    Protected WithEvents defaultParameterValuesList As System.Web.UI.WebControls.ListBox

    Private customersByCityReport As CustomersByCity
    Private Const PARAMETER_FIELD_NAME As String = "City"
    Private Const SUBREPORT_PARAMETER_FIELD_NAME As String = "OrderDateRange"
    Private Const SUBREPORT_NAME As String = "CustomerOrders"

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
        ConfigureCrystalReports()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ConfigureCrystalReports()
        customersByCityReport = New CustomersByCity()

        Dim myArrayList As ArrayList = New ArrayList()
        Dim startDate As String
        Dim endDate As String

        If Not IsPostBack Then
            defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport)
            defaultParameterValuesList.DataBind()
            myArrayList.Add("Paris")
            myArrayList.Add("Tokyo")
            Session("myArrayList") = myArrayList
            startDate = "8/1/1997"
            endDate = "8/31/1997"
            Session("startDate") = startDate
            Session("endDate") = endDate
        Else
            myArrayList = CType(Session("myArrayList"), ArrayList)
            startDate = Session("startDate").ToString()
            endDate = Session("endDate").ToString()
        End If

        SetCurrentValuesForParameterField(customersByCityReport, myArrayList)
        SetDateRangeForOrders(customersByCityReport, startDate, endDate)

        myCrystalReportViewer.ReportSource = customersByCityReport
    End Sub

    Private Sub SetCurrentValuesForParameterField(ByVal myReportDocument As ReportDocument, ByVal myArrayList As ArrayList)
        Dim currentParameterValues As ParameterValues = New ParameterValues()
        Dim submittedValue As Object
        For Each submittedValue In myArrayList
            Dim myParameterDiscreteValue As ParameterDiscreteValue = New ParameterDiscreteValue()
            myParameterDiscreteValue.Value = submittedValue.ToString()
            currentParameterValues.Add(myParameterDiscreteValue)
        Next
        Dim myParameterFieldDefinitions As ParameterFieldDefinitions = myReportDocument.DataDefinition.ParameterFields
        Dim myParameterFieldDefinition As ParameterFieldDefinition = myParameterFieldDefinitions(PARAMETER_FIELD_NAME)
        myParameterFieldDefinition.ApplyCurrentValues(currentParameterValues)

    End Sub

    Private Function GetDefaultValuesFromParameterField(ByVal myReportDocument As ReportDocument) As ArrayList
        Dim myParameterFieldDefinitions As ParameterFieldDefinitions = myReportDocument.DataDefinition.ParameterFields
        Dim myParameterFieldDefinition As ParameterFieldDefinition = myParameterFieldDefinitions(PARAMETER_FIELD_NAME)
        Dim defaultParameterValues As ParameterValues = myParameterFieldDefinition.DefaultValues

        Dim myArrayList As ArrayList = New ArrayList()
        Dim myParameterValue As ParameterValue
        For Each myParameterValue In defaultParameterValues
            If (Not myParameterValue.IsRange) Then
                Dim myParameterDiscreteValue As ParameterDiscreteValue = CType(myParameterValue, ParameterDiscreteValue)
                myArrayList.Add(myParameterDiscreteValue.Value.ToString())
            End If
        Next
        Return myArrayList

    End Function

    Private Sub SetDateRangeForOrders(ByVal myReportDocument As ReportDocument, ByVal startDate As String, ByVal endDate As String)
        Dim myParameterRangeValue As ParameterRangeValue = New ParameterRangeValue()
        myParameterRangeValue.StartValue = startDate
        myParameterRangeValue.EndValue = endDate
        myParameterRangeValue.LowerBoundType = RangeBoundType.BoundInclusive
        myParameterRangeValue.UpperBoundType = RangeBoundType.BoundInclusive

        Dim myParameterFields As ParameterFields = myReportDocument.ParameterFields
        Dim myParameterField As ParameterField = myParameterFields(SUBREPORT_PARAMETER_FIELD_NAME, SUBREPORT_NAME)
        myParameterField.CurrentValues.Clear()
        myParameterField.CurrentValues.Add(myParameterRangeValue)
    End Sub

    Private Sub redisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redisplay.Click
        Dim myArrayList As ArrayList = New ArrayList()
        Dim item As ListItem
        For Each item In defaultParameterValuesList.Items
            If item.Selected Then
                myArrayList.Add(item.Value)
            End If
        Next

        Session("myArrayList") = myArrayList
        Session("startDate") = orderStartDate.Text
        Session("endDate") = orderEndDate.Text

        ConfigureCrystalReports()
    End Sub
End Class
