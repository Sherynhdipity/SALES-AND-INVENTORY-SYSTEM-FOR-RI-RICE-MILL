using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace CS_Win_CRVObjMod_CustomizeViewer
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox listCRVToolbar;
		private System.Windows.Forms.Button redisplay;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox selectBackColor;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.CheckBox toolbar;
		private System.Windows.Forms.CheckBox groupTree;
		private System.Windows.Forms.TextBox pageNumber;
		private System.Windows.Forms.Button btnGoToPage;
		private System.Windows.Forms.TextBox zoomFactor;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button updateZoomFactor;
		private System.Windows.Forms.TextBox searchText;
		private System.Windows.Forms.Button search;
		private System.Windows.Forms.Label message;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ConfigureCrystalReports();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		private void ConfigureCrystalReports()
		{
			listCRVToolbar.DataSource = System.Enum.GetValues(typeof(CeWndCRVToolbarOptions));
			selectBackColor.DataSource = System.Enum.GetValues(typeof(KnownColor));
			toolbar.Checked = crystalReportViewer.DisplayToolbar;
			groupTree.Checked = crystalReportViewer.DisplayGroupTree;
			

			crystalReportViewer.ReportSource = @"C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Chart.rpt";

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.label1 = new System.Windows.Forms.Label();
			this.listCRVToolbar = new System.Windows.Forms.ListBox();
			this.redisplay = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.selectBackColor = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.toolbar = new System.Windows.Forms.CheckBox();
			this.groupTree = new System.Windows.Forms.CheckBox();
			this.pageNumber = new System.Windows.Forms.TextBox();
			this.btnGoToPage = new System.Windows.Forms.Button();
			this.zoomFactor = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.updateZoomFactor = new System.Windows.Forms.Button();
			this.searchText = new System.Windows.Forms.TextBox();
			this.search = new System.Windows.Forms.Button();
			this.message = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.crystalReportViewer.Location = new System.Drawing.Point(0, 176);
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(912, 408);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(288, 32);
			this.label1.TabIndex = 1;
			this.label1.Text = "Select the options for your CrystalReportViewer Toolbar";
			// 
			// listCRVToolbar
			// 
			this.listCRVToolbar.Location = new System.Drawing.Point(312, 8);
			this.listCRVToolbar.Name = "listCRVToolbar";
			this.listCRVToolbar.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.listCRVToolbar.Size = new System.Drawing.Size(208, 82);
			this.listCRVToolbar.TabIndex = 2;
			// 
			// redisplay
			// 
			this.redisplay.Location = new System.Drawing.Point(760, 144);
			this.redisplay.Name = "redisplay";
			this.redisplay.Size = new System.Drawing.Size(136, 23);
			this.redisplay.TabIndex = 3;
			this.redisplay.Text = "Redisplay Report";
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(552, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(136, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Select Background Color";
			this.label2.Click += new System.EventHandler(this.label2_Click);
			// 
			// selectBackColor
			// 
			this.selectBackColor.Location = new System.Drawing.Point(696, 8);
			this.selectBackColor.Name = "selectBackColor";
			this.selectBackColor.Size = new System.Drawing.Size(136, 21);
			this.selectBackColor.TabIndex = 5;
			this.selectBackColor.SelectedIndexChanged += new System.EventHandler(this.selectBackColor_SelectedIndexChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(552, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(216, 23);
			this.label3.TabIndex = 6;
			this.label3.Text = "Select the report components to display";
			this.label3.Click += new System.EventHandler(this.label3_Click);
			// 
			// toolbar
			// 
			this.toolbar.Location = new System.Drawing.Point(776, 48);
			this.toolbar.Name = "toolbar";
			this.toolbar.Size = new System.Drawing.Size(64, 24);
			this.toolbar.TabIndex = 7;
			this.toolbar.Text = "Toolbar";
			this.toolbar.CheckedChanged += new System.EventHandler(this.toolbar_CheckedChanged);
			// 
			// groupTree
			// 
			this.groupTree.Location = new System.Drawing.Point(776, 80);
			this.groupTree.Name = "groupTree";
			this.groupTree.Size = new System.Drawing.Size(88, 24);
			this.groupTree.TabIndex = 8;
			this.groupTree.Text = "Group Tree";
			this.groupTree.CheckedChanged += new System.EventHandler(this.groupTree_CheckedChanged);
			// 
			// pageNumber
			// 
			this.pageNumber.Location = new System.Drawing.Point(16, 112);
			this.pageNumber.Name = "pageNumber";
			this.pageNumber.Size = new System.Drawing.Size(48, 20);
			this.pageNumber.TabIndex = 9;
			this.pageNumber.Text = "";
			// 
			// btnGoToPage
			// 
			this.btnGoToPage.Location = new System.Drawing.Point(72, 112);
			this.btnGoToPage.Name = "btnGoToPage";
			this.btnGoToPage.Size = new System.Drawing.Size(88, 23);
			this.btnGoToPage.TabIndex = 10;
			this.btnGoToPage.Text = "Go To Page";
			this.btnGoToPage.Click += new System.EventHandler(this.btnGoToPage_Click);
			// 
			// zoomFactor
			// 
			this.zoomFactor.Location = new System.Drawing.Point(16, 144);
			this.zoomFactor.Name = "zoomFactor";
			this.zoomFactor.Size = new System.Drawing.Size(48, 20);
			this.zoomFactor.TabIndex = 11;
			this.zoomFactor.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(72, 144);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(24, 23);
			this.label4.TabIndex = 12;
			this.label4.Text = "%";
			// 
			// updateZoomFactor
			// 
			this.updateZoomFactor.Location = new System.Drawing.Point(96, 144);
			this.updateZoomFactor.Name = "updateZoomFactor";
			this.updateZoomFactor.Size = new System.Drawing.Size(64, 23);
			this.updateZoomFactor.TabIndex = 13;
			this.updateZoomFactor.Text = "Zoom";
			this.updateZoomFactor.Click += new System.EventHandler(this.updateZoomFactor_Click);
			// 
			// searchText
			// 
			this.searchText.Location = new System.Drawing.Point(304, 112);
			this.searchText.Name = "searchText";
			this.searchText.TabIndex = 14;
			this.searchText.Text = "";
			// 
			// search
			// 
			this.search.Location = new System.Drawing.Point(416, 112);
			this.search.Name = "search";
			this.search.TabIndex = 15;
			this.search.Text = "Search";
			this.search.Click += new System.EventHandler(this.search_Click);
			// 
			// message
			// 
			this.message.Location = new System.Drawing.Point(504, 112);
			this.message.Name = "message";
			this.message.Size = new System.Drawing.Size(176, 23);
			this.message.TabIndex = 16;
			this.message.Text = "Search Result";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(912, 590);
			this.Controls.Add(this.message);
			this.Controls.Add(this.search);
			this.Controls.Add(this.searchText);
			this.Controls.Add(this.updateZoomFactor);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.zoomFactor);
			this.Controls.Add(this.btnGoToPage);
			this.Controls.Add(this.pageNumber);
			this.Controls.Add(this.groupTree);
			this.Controls.Add(this.toolbar);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.selectBackColor);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.redisplay);
			this.Controls.Add(this.listCRVToolbar);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.crystalReportViewer);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.ShowPageNavigateButtons = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Page_Navigation));
			crystalReportViewer.ShowGotoPageButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Go_to_Page));
			crystalReportViewer.ShowCloseButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Close_View));
			crystalReportViewer.ShowPrintButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Print));
			crystalReportViewer.ShowRefreshButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Refresh));
			crystalReportViewer.ShowExportButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Export));
			crystalReportViewer.ShowGroupTreeButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Group_Tree));
			crystalReportViewer.ShowZoomButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Zoom));
			crystalReportViewer.ShowTextSearchButton = listCRVToolbar.GetSelected(Convert.ToInt32(CeWndCRVToolbarOptions.Search));

			KnownColor selectedKnownColor = (KnownColor)selectBackColor.SelectedItem;
			if (selectedKnownColor != KnownColor.Transparent)
			{
				crystalReportViewer.BackColor = System.Drawing.Color.FromKnownColor(selectedKnownColor);
			}
			crystalReportViewer.DisplayToolbar = toolbar.Checked;
			crystalReportViewer.DisplayGroupTree = groupTree.Checked;
			
		}

		private void label2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void label3_Click(object sender, System.EventArgs e)
		{
		
		}

		private void toolbar_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private void selectBackColor_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void groupTree_CheckedChanged(object sender, System.EventArgs e)
		{
		
		}

		private void btnGoToPage_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.ShowNthPage(Convert.ToInt32(pageNumber.Text));
		}

		private void updateZoomFactor_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.Zoom(Convert.ToInt32(zoomFactor.Text));
		}

		private void search_Click(object sender, System.EventArgs e)
		{
			bool searchResult = crystalReportViewer.SearchForText(searchText.Text);
			if (searchResult)
			{
				message.Text = "Search results found.";
			}
			else
			{
				message.Text = "Search results not found.";
			}
		}
	}
}
