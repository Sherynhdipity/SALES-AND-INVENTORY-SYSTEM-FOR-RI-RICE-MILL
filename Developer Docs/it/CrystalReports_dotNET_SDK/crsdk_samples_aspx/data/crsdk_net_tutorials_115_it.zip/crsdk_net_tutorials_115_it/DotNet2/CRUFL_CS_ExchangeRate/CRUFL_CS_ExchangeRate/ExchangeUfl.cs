using System;
using System.Collections.Generic;
using System.Text;

using System.Runtime.InteropServices;


namespace CRUFL_CS_ExchangeRate
{

	[ComVisible(true), ClassInterface(ClassInterfaceType.None), Guid("197222DE-FD22-4eb2-8B16-C82B9C620FA7")]
	
	public class ExchangeUfl : IExchangeUfl
	{
		public double ConvertUSDollarsToCDN(double usd)
		{
			if (usd > Double.MaxValue)
			{
				throw new Exception("Value submitted is larger than the maximum value allowed for a double.");
			}

			return (usd * 1.45);
		}

	}
}
