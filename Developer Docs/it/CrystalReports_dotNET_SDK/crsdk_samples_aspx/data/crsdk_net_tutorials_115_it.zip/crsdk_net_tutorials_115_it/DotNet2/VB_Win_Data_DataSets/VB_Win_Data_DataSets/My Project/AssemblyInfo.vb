﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("VB_Win_Data_DataSets")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Business Objects")> 
<Assembly: AssemblyProduct("VB_Win_Data_DataSets")> 
<Assembly: AssemblyCopyright("Copyright © Business Objects 2005")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: CLSCompliant(True)> 

<Assembly: ComVisible(False)>

<Assembly: Guid("c95599cb-1193-46b7-8a03-95eed84a98de")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
