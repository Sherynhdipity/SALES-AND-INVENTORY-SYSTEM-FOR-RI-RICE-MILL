using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public class Stock
{
    private string _symbol;
    private double _price;
    private int _volume;

	public Stock()
	{

	}

    public string Symbol
    {
        get
        {
            return _symbol;
        }
        set
        {
            _symbol = value;
        }
    }
    public double Price
    {
        get
        {
            return _price;
        }
        set
        {
            _price = value;
        }
    }
    public int Volume
    {
        get
        {
            return _volume;
        }
        set
        {
            _volume = value;
        }
    }
    public Stock(String symbol, int volume, double price)
    {
        _symbol = symbol;
        _volume = volume;
        _price = price;
    }

}
