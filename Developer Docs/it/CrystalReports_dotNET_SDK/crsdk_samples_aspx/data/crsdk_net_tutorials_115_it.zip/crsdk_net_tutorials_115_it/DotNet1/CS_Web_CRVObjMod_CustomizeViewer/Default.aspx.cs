using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Web_CRVObjMod_CustomizeViewer
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ListBox listCRVToolbar;
		protected System.Web.UI.WebControls.DropDownList selectBackColor;
		protected System.Web.UI.WebControls.CheckBox toolbar;
		protected System.Web.UI.WebControls.CheckBox groupTree;
		protected System.Web.UI.WebControls.CheckBox mainPage;
		protected System.Web.UI.WebControls.CheckBox separatePages;
		protected System.Web.UI.WebControls.Button redisplay;
		protected System.Web.UI.WebControls.DropDownList selectPrintMode;
		protected System.Web.UI.WebControls.TextBox pageNumber;
		protected System.Web.UI.WebControls.Button btnGoToPage;
		protected System.Web.UI.WebControls.TextBox zoomFactor;
		protected System.Web.UI.WebControls.Button updateZoomFactor;
		protected System.Web.UI.WebControls.TextBox searchText;
		protected System.Web.UI.WebControls.Button search;
		protected System.Web.UI.WebControls.Label message;
		protected System.Web.UI.WebControls.TextBox borderWidth;
		protected System.Web.UI.WebControls.DropDownList selectBorderStyle;
		protected System.Web.UI.WebControls.DropDownList selectBorderColor;
		protected System.Web.UI.WebControls.Button drawBorder;
		protected CrystalDecisions.Web.CrystalReportViewer crystalReportViewer;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void ConfigureCrystalReports()
		{
			ArrayList printModeList = new ArrayList();
			if (!IsPostBack)
			{
				listCRVToolbar.DataSource = System.Enum.GetValues(typeof(CeWebCRVToolbarOptions));
				listCRVToolbar.DataBind();

				selectBackColor.DataSource = System.Enum.GetValues(typeof(KnownColor));
				selectBackColor.DataBind();

				printModeList.Add("PDF Format");
				printModeList.Add("ActiveX");
				selectPrintMode.DataSource = printModeList;
				selectPrintMode.DataBind();

				selectBorderStyle.DataSource = System.Enum.GetValues(typeof(BorderStyle));
				selectBorderStyle.DataBind();

				selectBorderColor.DataSource = System.Enum.GetValues(typeof(KnownColor));
				selectBorderColor.DataBind();

				Session["backColor"] = crystalReportViewer.BackColor.ToString();
				Session["borderColor"] = crystalReportViewer.BorderColor.ToString();
				Session["borderStyle"] = crystalReportViewer.BorderStyle;

				if (!borderWidth.Text.Equals(""))
				{
					Session["borderWidth"] = crystalReportViewer.BorderWidth;
				}
			}
			else
			{
				crystalReportViewer.BackColor = System.Drawing.Color.FromName((string)Session["backColor"]);
				crystalReportViewer.BorderColor = System.Drawing.Color.FromName((string)Session["borderColor"]);
				crystalReportViewer.BorderStyle = (BorderStyle)Session["borderStyle"];
				crystalReportViewer.BorderWidth = Convert.ToInt32(Session["borderStyle"]);
			}
			toolbar.Checked = crystalReportViewer.DisplayToolbar;
			groupTree.Checked = crystalReportViewer.DisplayGroupTree;
			mainPage.Checked = crystalReportViewer.DisplayPage;
			separatePages.Checked = crystalReportViewer.SeparatePages;

			crystalReportViewer.ReportSource = "C:\\Program Files\\Business Objects\\Crystal Reports 11.5\\Samples\\en\\Reports\\Feature Examples\\Chart.rpt";
		}



		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			ConfigureCrystalReports();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			this.selectPrintMode.SelectedIndexChanged += new System.EventHandler(this.selectPrintMode_SelectedIndexChanged);
			this.btnGoToPage.Click += new System.EventHandler(this.btnGoToPage_Click);
			this.updateZoomFactor.Click += new System.EventHandler(this.updateZoomFactor_Click);
			this.search.Click += new System.EventHandler(this.search_Click);
			this.drawBorder.Click += new System.EventHandler(this.drawBorder_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.HasToggleGroupTreeButton = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Group_Tree)].Selected;
			crystalReportViewer.HasExportButton = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Export)].Selected;
			crystalReportViewer.HasPrintButton = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Print)].Selected;
			crystalReportViewer.HasViewList = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.View_List)].Selected;
			crystalReportViewer.HasDrillUpButton = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Drill_Up)].Selected;
			crystalReportViewer.HasPageNavigationButtons = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Page_Navigation)].Selected;
			crystalReportViewer.HasGotoPageButton = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Go_to_Page)].Selected;
			crystalReportViewer.HasSearchButton = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Search)].Selected;
			crystalReportViewer.HasZoomFactorList = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Zoom)].Selected;
			crystalReportViewer.HasCrystalLogo = listCRVToolbar.Items[Convert.ToInt32(CeWebCRVToolbarOptions.Crystal_Logo)].Selected;

			crystalReportViewer.BackColor = System.Drawing.Color.FromName(selectBackColor.SelectedItem.Text);
			crystalReportViewer.DisplayToolbar = toolbar.Checked;
			crystalReportViewer.DisplayGroupTree = groupTree.Checked;
			crystalReportViewer.DisplayPage = mainPage.Checked;
			crystalReportViewer.SeparatePages = separatePages.Checked;

			Session["backColor"] = selectBackColor.SelectedItem.Text;
		}

		private void btnGoToPage_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.ShowNthPage(Convert.ToInt32(pageNumber.Text));
		}

		private void updateZoomFactor_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.Zoom(Convert.ToInt32(zoomFactor.Text));
		}

		private void search_Click(object sender, System.EventArgs e)
		{
			crystalReportViewer.ReportSource = "C:\\Program Files\\Business Objects\\Crystal Reports 11.5\\Samples\\en\\Reports\\Feature Examples\\Chart.rpt";
			bool searchResult = crystalReportViewer.SearchForText(searchText.Text, SearchDirection.Forward);
			if (!searchResult)
			{
				message.Text = "Search results found.";
			}
			else
			{
				message.Text = "Search results not found.";
			}
		}

		private void drawBorder_Click(object sender, System.EventArgs e)
		{
			if (!borderWidth.Text.Equals(""))
			{
				crystalReportViewer.BorderWidth = Convert.ToInt32(borderWidth.Text);
				Session["borderWidth"] = borderWidth.Text;
			}
			crystalReportViewer.BorderStyle = (BorderStyle)selectBorderStyle.SelectedIndex;
			crystalReportViewer.BorderColor = System.Drawing.Color.FromName(selectBorderColor.SelectedItem.Text);

			Session["borderStyle"] = selectBorderStyle.SelectedIndex;
			Session["borderColor"] = selectBorderColor.SelectedItem.Text;
		}

		private void selectPrintMode_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (selectPrintMode.SelectedIndex == 0)
				crystalReportViewer.PrintMode = CrystalDecisions.Web.PrintMode.Pdf;
			else
				crystalReportViewer.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX;
		}
	}
}
