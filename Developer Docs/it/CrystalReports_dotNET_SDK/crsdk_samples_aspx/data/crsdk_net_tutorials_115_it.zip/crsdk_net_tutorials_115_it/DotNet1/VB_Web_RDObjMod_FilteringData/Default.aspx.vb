Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class _Default
    Inherits System.Web.UI.Page
    Protected WithEvents myCrystalReportViewer As CrystalDecisions.Web.CrystalReportViewer
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents lastYearsSales As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents operatorValueList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents name As System.Web.UI.WebControls.TextBox
    Protected WithEvents redisplay As System.Web.UI.WebControls.Button
    Protected WithEvents formula As System.Web.UI.WebControls.Label

    Private customerBySalesNameReport As CustomerBySalesName
    Private salesAmount As String
    Private operatorValue As String
    Private customerName As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
        ConfigureCrystalReports()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ConfigureCrystalReports()
        If Not IsPostBack Then
            operatorValueList.DataSource = System.Enum.GetValues(GetType(CeComparisonOperator))
            operatorValueList.DataBind()

            salesAmount = "11000"
            operatorValue = "="
            customerName = "A"
        End If

        Dim selectionFormula As String = "{Customer.Last Year's Sales} > " _
            & salesAmount _
            & " AND Mid({Customer.Customer Name}, 1, 1) " _
            & operatorValue _
            & "'" _
            & customerName _
            & "'"

        customerBySalesNameReport = New CustomerBySalesName()
        customerBySalesNameReport.DataDefinition.RecordSelectionFormula = selectionFormula
        myCrystalReportViewer.ReportSource = customerBySalesNameReport
        formula.Text = selectionFormula
    End Sub

    Private Function GetSelectedOperator() As String
        Dim selectedOperator As String = ""

        Select Case operatorValueList.SelectedIndex
            Case CeComparisonOperator.EqualTo
                selectedOperator = "="
            Case CeComparisonOperator.GreaterThan
                selectedOperator = ">"
            Case CeComparisonOperator.GreaterThanOrEqualTo
                selectedOperator = ">="
            Case CeComparisonOperator.LessThan
                selectedOperator = "<"
            Case CeComparisonOperator.LessThanOrEqualTo
                selectedOperator = "<="
            Case CeComparisonOperator.NotEqualTo
                selectedOperator = "<>"
        End Select

        Return selectedOperator
    End Function

    Private Sub redisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redisplay.Click
        salesAmount = lastYearsSales.Text
        operatorValue = GetSelectedOperator()
        customerName = name.Text

        ConfigureCrystalReports()
    End Sub
End Class
