Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class _Default
    Inherits System.Web.UI.Page
    Protected WithEvents listCRVToolbar As System.Web.UI.WebControls.ListBox
    Protected WithEvents selectBackColor As System.Web.UI.WebControls.DropDownList
    Protected WithEvents toolbar As System.Web.UI.WebControls.CheckBox
    Protected WithEvents groupTree As System.Web.UI.WebControls.CheckBox
    Protected WithEvents mainPage As System.Web.UI.WebControls.CheckBox
    Protected WithEvents separatePages As System.Web.UI.WebControls.CheckBox
    Protected WithEvents redisplay As System.Web.UI.WebControls.Button
    Protected WithEvents selectPrintMode As System.Web.UI.WebControls.DropDownList
    Protected WithEvents pageNumber As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnGoToPage As System.Web.UI.WebControls.Button
    Protected WithEvents zoomFactor As System.Web.UI.WebControls.TextBox
    Protected WithEvents updateZoomFactor As System.Web.UI.WebControls.Button
    Protected WithEvents searchText As System.Web.UI.WebControls.TextBox
    Protected WithEvents search As System.Web.UI.WebControls.Button
    Protected WithEvents message As System.Web.UI.WebControls.Label
    Protected WithEvents borderWidth As System.Web.UI.WebControls.TextBox
    Protected WithEvents selectBorderStyle As System.Web.UI.WebControls.DropDownList
    Protected WithEvents selectBorderColor As System.Web.UI.WebControls.DropDownList
    Protected WithEvents drawBorder As System.Web.UI.WebControls.Button
    Protected WithEvents myCrystalreportviewer As CrystalDecisions.Web.CrystalReportViewer

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
        ConfigureCrystalReports()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ConfigureCrystalReports()
        Dim printModeList As ArrayList = New ArrayList()

        If Not IsPostBack Then
            listCRVToolbar.DataSource = System.Enum.GetValues(GetType(CeWebCRVToolbarOptions))
            listCRVToolbar.DataBind()

            selectBackColor.DataSource = System.Enum.GetValues(GetType(KnownColor))
            selectBackColor.DataBind()

            printModeList.Add("PDF Format")
            printModeList.Add("ActiveX")
            selectPrintMode.DataSource = printModeList
            selectPrintMode.DataBind()

            selectBorderStyle.DataSource = System.Enum.GetValues(GetType(BorderStyle))
            selectBorderStyle.DataBind()

            selectBorderColor.DataSource = System.Enum.GetValues(GetType(KnownColor))
            selectBorderColor.DataBind()

            Session("myBackColor") = myCrystalreportviewer.BackColor.ToString()
            Session("myBorderColor") = myCrystalreportviewer.BorderColor.ToString()
            Session("myBorderStyle") = myCrystalreportviewer.BorderStyle
            If Not borderWidth.Text.Equals("") Then
                Session("myBorderWidth") = myCrystalreportviewer.BorderWidth
            End If
        Else
            myCrystalreportviewer.BackColor = System.Drawing.Color.FromName(CType(Session("myBackColor"), String))
            myCrystalreportviewer.BorderColor = System.Drawing.Color.FromName(CType(Session("myBorderColor"), String))
            myCrystalreportviewer.BorderStyle = CType(Session("myBorderStyle"), BorderStyle)
            myCrystalreportviewer.BorderWidth = CType(Session("myBorderWidth"), Unit)
        End If

        toolbar.Checked = myCrystalreportviewer.DisplayToolbar
        groupTree.Checked = myCrystalreportviewer.DisplayGroupTree
        mainPage.Checked = myCrystalreportviewer.DisplayPage
        separatePages.Checked = myCrystalreportviewer.SeparatePages

        myCrystalreportviewer.ReportSource = "C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Chart.rpt"
    End Sub

    Private Sub redisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redisplay.Click
        myCrystalreportviewer.HasToggleGroupTreeButton = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Group_Tree)).Selected
        myCrystalreportviewer.HasExportButton = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Export)).Selected
        myCrystalreportviewer.HasPrintButton = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Print)).Selected
        myCrystalreportviewer.HasViewList = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.View_List)).Selected
        myCrystalreportviewer.HasDrillUpButton = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Drill_Up)).Selected
        myCrystalreportviewer.HasPageNavigationButtons = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Page_Navigation)).Selected
        myCrystalreportviewer.HasGotoPageButton = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Go_to_Page)).Selected
        myCrystalreportviewer.HasSearchButton = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Search)).Selected
        myCrystalreportviewer.HasZoomFactorList = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Zoom)).Selected
        myCrystalreportviewer.HasCrystalLogo = listCRVToolbar.Items(Convert.ToInt32(CeWebCRVToolbarOptions.Crystal_Logo)).Selected

        myCrystalreportviewer.BackColor = System.Drawing.Color.FromName(selectBackColor.SelectedItem.Text)
        myCrystalreportviewer.DisplayToolbar = toolbar.Checked
        myCrystalreportviewer.DisplayGroupTree = groupTree.Checked
        myCrystalreportviewer.DisplayPage = mainPage.Checked
        myCrystalreportviewer.SeparatePages = separatePages.Checked

        Session("myBackColor") = selectBackColor.SelectedItem.Text
    End Sub

    Private Sub btnGoToPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoToPage.Click
        myCrystalreportviewer.ShowNthPage(Convert.ToInt32(pageNumber.Text))
    End Sub

    Private Sub updateZoomFactor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updateZoomFactor.Click
        myCrystalreportviewer.Zoom(Convert.ToInt32(zoomFactor.Text))
    End Sub

    Private Sub search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles search.Click
        myCrystalreportviewer.ReportSource = "C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Chart.rpt"
        Dim mySearchResult As Boolean = myCrystalreportviewer.SearchForText(searchText.Text, SearchDirection.Forward)
        If Not mySearchResult Then
            message.Text = "Search results found."
        Else
            message.Text = "Search results not found."
        End If
    End Sub

    Private Sub drawBorder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles drawBorder.Click
        If Not borderWidth.Text.Equals("") Then
            myCrystalreportviewer.BorderWidth = Unit.Parse(borderWidth.Text.ToString())
            Session("myBorderWidth") = borderWidth.Text
        End If
        myCrystalreportviewer.BorderStyle = CType(selectBorderStyle.SelectedIndex, BorderStyle)
        myCrystalreportviewer.BorderColor = System.Drawing.Color.FromName(selectBorderColor.SelectedItem.Text)

        Session("myBorderStyle") = selectBorderStyle.SelectedIndex
        Session("myBorderColor") = selectBorderColor.SelectedItem.Text
    End Sub

    Private Sub selectPrintMode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles selectPrintMode.SelectedIndexChanged
        If selectPrintMode.SelectedIndex = 0 Then
            myCrystalreportviewer.PrintMode = CrystalDecisions.Web.PrintMode.Pdf
        Else
            myCrystalreportviewer.PrintMode = CrystalDecisions.Web.PrintMode.ActiveX
        End If
    End Sub
End Class
