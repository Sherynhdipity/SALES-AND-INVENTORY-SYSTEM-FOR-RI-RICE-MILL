using System;

namespace CS_Win_CRVObjMod_CustomizeViewer
{
	public enum CeWndCRVToolbarOptions
	{
		Page_Navigation,
		Go_to_Page,
		Close_View,
		Print,
		Refresh,
		Export,
		Group_Tree,
		Zoom,
		Search
	}
}
