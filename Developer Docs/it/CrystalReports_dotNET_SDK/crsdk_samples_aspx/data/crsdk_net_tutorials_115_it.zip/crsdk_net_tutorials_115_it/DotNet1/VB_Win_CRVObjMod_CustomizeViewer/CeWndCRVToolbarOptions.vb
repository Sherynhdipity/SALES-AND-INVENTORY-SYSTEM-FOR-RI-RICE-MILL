Public Enum CeWndCRVToolbarOptions
    Page_Navigation
    Go_to_Page
    Close_View
    Print
    Refresh
    Export
    Group_Tree
    Zoom
    Search
End Enum

