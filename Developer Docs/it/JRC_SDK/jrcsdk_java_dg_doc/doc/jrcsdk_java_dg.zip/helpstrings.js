var contents = 'Contents';
var index = 'Index';
var noframes = 'This help system requires a web browser that supports frames';
