﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Collections;

namespace CS_Win_RDObjMod_SetPrintOptions
{
    public partial class Form1 : Form
    {
        private const string CURRENT_PRINTER = @"\\vanprt04\C3-8N-DOC";
        ReportDocument hierarchicalGroupingReport = new ReportDocument();
        public Form1()
        {
            InitializeComponent();
        }

        private void ConfigureCrystalReports()
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ConfigureCrystalReports();

            paperOrientationList.DataSource = System.Enum.GetValues(typeof(PaperOrientation));
            paperSizeList.DataSource = System.Enum.GetValues(typeof(PaperSize));
            printerDuplexList.DataSource = System.Enum.GetValues(typeof(PrinterDuplex));
            paperSourceList.DataSource = GetPaperSources();
        }

        private void crystalReportViewer_Load(object sender, EventArgs e)
        {

        }

        private ArrayList GetPaperSources()
        {
            ArrayList arrayList = new ArrayList();
            System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
            printerSettings.PrinterName = CURRENT_PRINTER;
            foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
            {
                arrayList.Add(paperSource.SourceName.ToString());
            }
            return arrayList;
        }

        private System.Drawing.Printing.PaperSource GetSelectedPaperSource()
        {
            System.Drawing.Printing.PaperSource selectedPaperSource = new System.Drawing.Printing.PaperSource();
            System.Drawing.Printing.PrinterSettings printerSettings = new System.Drawing.Printing.PrinterSettings();
            printerSettings.PrinterName = CURRENT_PRINTER;
            foreach (System.Drawing.Printing.PaperSource paperSource in printerSettings.PaperSources)
            {
                if (paperSource.SourceName == paperSourceList.SelectedText)
                {
                    selectedPaperSource = paperSource;
                }
            }
            return selectedPaperSource;
        }

        private void SetPrintOptions()
        {
            PrintOptions printOptions = hierarchicalGroupingReport.PrintOptions;
            printOptions.PrinterName = CURRENT_PRINTER;
            printOptions.PaperOrientation = (PaperOrientation)paperOrientationList.SelectedIndex;
            printOptions.PaperSize = (PaperSize)paperSizeList.SelectedIndex;
            printOptions.PrinterDuplex = (PrinterDuplex)printerDuplexList.SelectedIndex;
        }

        private void printReport_Click(object sender, EventArgs e)
        {
            SetPrintOptions();
            try
            {
                hierarchicalGroupingReport.PrintToPrinter(1, false, 1, 99);
                message.Text = MessageConstants.SUCCESS;
            }
            catch (Exception ex)
            {
                message.Text = MessageConstants.FAILURE + ex.Message;
            }

        }


    }
}