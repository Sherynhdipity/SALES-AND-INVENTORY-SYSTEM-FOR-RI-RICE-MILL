﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class Form1

    Private Sub ConfigureCrystalReports()
        Dim myConnectionInfo As ConnectionInfo = New ConnectionInfo()
        myConnectionInfo.DatabaseName = "Northwind"
        myConnectionInfo.UserID = "limitedPermissionAccount"
        myConnectionInfo.Password = "1234"
        myConnectionInfo.ServerName = "dholmes_50701"
        Dim reportPath As String = Application.StartupPath & "\" & "NorthwindCustomers.rpt"
        myCrystalReportViewer.ReportSource = reportPath
        SetDBLogonForReport(myConnectionInfo)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ConfigureCrystalReports()
    End Sub

    Private Sub SetDBLogonForReport(ByVal myConnectionInfo As ConnectionInfo)
        Dim myTableLogOnInfos As TableLogOnInfos = myCrystalReportViewer.LogOnInfo
        For Each myTableLogOnInfo As TableLogOnInfo In myTableLogOnInfos
            myTableLogOnInfo.ConnectionInfo = myConnectionInfo

        Next
    End Sub

End Class
