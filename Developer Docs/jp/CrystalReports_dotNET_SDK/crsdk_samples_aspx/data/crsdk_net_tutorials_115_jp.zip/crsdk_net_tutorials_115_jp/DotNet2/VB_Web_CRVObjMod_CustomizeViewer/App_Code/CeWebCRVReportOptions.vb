Imports Microsoft.VisualBasic

Public Enum CeWebCRVReportOptions
    Toolbar
    Group_Tree
    Main_Page
    Enable_Separate_Pages

End Enum
