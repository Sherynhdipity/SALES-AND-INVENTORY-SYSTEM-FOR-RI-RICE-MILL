Imports Microsoft.VisualBasic

Public Enum CeComparisonOperator
    EqualTo
    GreaterThan
    GreaterThanOrEqualTo
    LessThan
    LessThanOrEqualTo
    NotEqualTo

End Enum
