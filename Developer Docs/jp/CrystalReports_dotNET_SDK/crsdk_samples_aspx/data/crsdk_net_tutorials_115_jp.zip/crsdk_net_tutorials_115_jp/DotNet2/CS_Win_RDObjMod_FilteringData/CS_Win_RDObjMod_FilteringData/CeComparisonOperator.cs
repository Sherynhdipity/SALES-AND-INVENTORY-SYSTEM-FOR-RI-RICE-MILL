using System;
using System.Collections.Generic;
using System.Text;

namespace CS_Win_RDObjMod_FilteringData
{
    enum CeComparisonOperator
    {
        EqualTo,
        GreaterThan,
        GreaterThanOrEqualTo,
        LessThan,
        LessThanOrEqualTo,
        NotEqualTo

    }
}
