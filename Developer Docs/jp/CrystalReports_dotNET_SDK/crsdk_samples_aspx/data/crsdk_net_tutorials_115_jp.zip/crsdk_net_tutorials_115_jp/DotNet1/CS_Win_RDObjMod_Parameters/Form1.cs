using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace CS_Win_RDObjectModel_DiscreteParameters
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private CustomersByCity customersByCityReport;
		private System.Windows.Forms.ListBox defaultParameterValuesList;
		private System.Windows.Forms.Button redisplay;
		private const string PARAMETER_FIELD_NAME = "City";

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			ConfigureCrystalReports();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.crystalReportViewer = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
			this.defaultParameterValuesList = new System.Windows.Forms.ListBox();
			this.redisplay = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// crystalReportViewer
			// 
			this.crystalReportViewer.ActiveViewIndex = -1;
			this.crystalReportViewer.Location = new System.Drawing.Point(0, 120);
			this.crystalReportViewer.Name = "crystalReportViewer";
			this.crystalReportViewer.ReportSource = null;
			this.crystalReportViewer.Size = new System.Drawing.Size(624, 376);
			this.crystalReportViewer.TabIndex = 0;
			// 
			// defaultParameterValuesList
			// 
			this.defaultParameterValuesList.Location = new System.Drawing.Point(8, 8);
			this.defaultParameterValuesList.Name = "defaultParameterValuesList";
			this.defaultParameterValuesList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.defaultParameterValuesList.Size = new System.Drawing.Size(120, 95);
			this.defaultParameterValuesList.TabIndex = 1;
			// 
			// redisplay
			// 
			this.redisplay.Location = new System.Drawing.Point(160, 80);
			this.redisplay.Name = "redisplay";
			this.redisplay.Size = new System.Drawing.Size(144, 23);
			this.redisplay.TabIndex = 2;
			this.redisplay.Text = "Redisplay Report";
			this.redisplay.Click += new System.EventHandler(this.redisplay_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(608, 494);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.redisplay,
																		  this.defaultParameterValuesList,
																		  this.crystalReportViewer});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void ConfigureCrystalReports()
		{
			customersByCityReport = new CustomersByCity();

			ArrayList arrayList = new ArrayList();
			arrayList.Add("Paris");
			arrayList.Add("Tokyo");

			defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport);

			SetCurrentValuesForParameterField(customersByCityReport, arrayList);

			crystalReportViewer.ReportSource = customersByCityReport;
		}

		private void SetCurrentValuesForParameterField(ReportDocument reportDocument, ArrayList arrayList)
		{
			ParameterValues currentParameterValues = new ParameterValues();
			foreach (object submittedValue in arrayList)
			{
				ParameterDiscreteValue parameterDiscreteValue = new ParameterDiscreteValue();
				parameterDiscreteValue.Value = submittedValue.ToString();
				currentParameterValues.Add(parameterDiscreteValue);
			}
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;
			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			parameterFieldDefinition.ApplyCurrentValues(currentParameterValues);
		}

		private ArrayList GetDefaultValuesFromParameterField(ReportDocument reportDocument)
		{
			ParameterFieldDefinitions parameterFieldDefinitions = reportDocument.DataDefinition.ParameterFields;
			ParameterFieldDefinition parameterFieldDefinition = parameterFieldDefinitions[PARAMETER_FIELD_NAME];
			ParameterValues defaultParameterValues = parameterFieldDefinition.DefaultValues;

			ArrayList arrayList = new ArrayList();

			foreach (ParameterValue parameterValue in defaultParameterValues)
			{
				if (!parameterValue.IsRange)
				{
					ParameterDiscreteValue parameterDiscreteValue = (ParameterDiscreteValue)parameterValue;
					arrayList.Add(parameterDiscreteValue.Value.ToString());
				}
			}
			return arrayList;
		}

		private void redisplay_Click(object sender, System.EventArgs e)
		{
			ArrayList arrayList = new ArrayList();
			foreach (string item in defaultParameterValuesList.SelectedItems)
			{
				arrayList.Add(item);
			}
			SetCurrentValuesForParameterField(customersByCityReport, arrayList);
			crystalReportViewer.ReportSource = customersByCityReport;
		}

	}
}
