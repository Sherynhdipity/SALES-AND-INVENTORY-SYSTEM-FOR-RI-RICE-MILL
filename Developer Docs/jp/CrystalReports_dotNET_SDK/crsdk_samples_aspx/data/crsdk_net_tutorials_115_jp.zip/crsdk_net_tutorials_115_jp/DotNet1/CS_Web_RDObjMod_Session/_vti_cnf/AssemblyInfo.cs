vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Nov 2004 00:45:20 -0000
vti_extenderversion:SR|4.0.2.7802
