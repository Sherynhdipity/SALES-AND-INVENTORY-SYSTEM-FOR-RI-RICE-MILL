Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private customersByCityReport As CustomersByCity
    Private Const PARAMETER_FIELD_NAME As String = "City"
    Private Const SUBREPORT_PARAMETER_FIELD_NAME As String = "OrderDateRange"
    Private Const SUBREPORT_NAME As String = "CustomerOrders"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        ConfigureCrystalReports()
        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents myCrystalReportViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents defaultParameterValuesList As System.Windows.Forms.ListBox
    Friend WithEvents redisplay As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.myCrystalReportViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.defaultParameterValuesList = New System.Windows.Forms.ListBox
        Me.redisplay = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.orderStartDate = New System.Windows.Forms.TextBox
        Me.orderEndDate = New System.Windows.Forms.TextBox
        Me.SuspendLayout()
        '
        'myCrystalReportViewer
        '
        Me.myCrystalReportViewer.ActiveViewIndex = -1
        Me.myCrystalReportViewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.myCrystalReportViewer.Location = New System.Drawing.Point(0, 126)
        Me.myCrystalReportViewer.Name = "myCrystalReportViewer"
        Me.myCrystalReportViewer.ReportSource = Nothing
        Me.myCrystalReportViewer.Size = New System.Drawing.Size(592, 352)
        Me.myCrystalReportViewer.TabIndex = 0
        '
        'defaultParameterValuesList
        '
        Me.defaultParameterValuesList.Location = New System.Drawing.Point(8, 8)
        Me.defaultParameterValuesList.Name = "defaultParameterValuesList"
        Me.defaultParameterValuesList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.defaultParameterValuesList.Size = New System.Drawing.Size(120, 95)
        Me.defaultParameterValuesList.TabIndex = 1
        '
        'redisplay
        '
        Me.redisplay.Location = New System.Drawing.Point(144, 80)
        Me.redisplay.Name = "redisplay"
        Me.redisplay.Size = New System.Drawing.Size(144, 23)
        Me.redisplay.TabIndex = 2
        Me.redisplay.Text = "Redisplay Report"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(152, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Order Start Date"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(152, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Order End Date"
        '
        'orderStartDate
        '
        Me.orderStartDate.Location = New System.Drawing.Point(272, 16)
        Me.orderStartDate.Name = "orderStartDate"
        Me.orderStartDate.TabIndex = 5
        Me.orderStartDate.Text = ""
        '
        'orderEndDate
        '
        Me.orderEndDate.Location = New System.Drawing.Point(272, 48)
        Me.orderEndDate.Name = "orderEndDate"
        Me.orderEndDate.TabIndex = 6
        Me.orderEndDate.Text = ""
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(592, 478)
        Me.Controls.Add(Me.orderEndDate)
        Me.Controls.Add(Me.orderStartDate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.redisplay)
        Me.Controls.Add(Me.defaultParameterValuesList)
        Me.Controls.Add(Me.myCrystalReportViewer)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ConfigureCrystalReports()
        customersByCityReport = New CustomersByCity()

        Dim myArrayList As ArrayList = New ArrayList()
        myArrayList.Add("Paris")
        myArrayList.Add("Tokyo")
        Dim startDate As String = "8/1/2004"
        orderStartDate.Text = startDate

        Dim endDate As String = "8/31/2004"
        orderEndDate.Text = endDate

        defaultParameterValuesList.DataSource = GetDefaultValuesFromParameterField(customersByCityReport)

        SetCurrentValuesForParameterField(customersByCityReport, myArrayList)
        SetDateRangeForOrders(customersByCityReport, startDate, endDate)

        myCrystalReportViewer.ReportSource = customersByCityReport
    End Sub

    Private Sub SetCurrentValuesForParameterField(ByVal myReportDocument As ReportDocument, ByVal myArrayList As ArrayList)
        Dim currentParameterValues As ParameterValues = New ParameterValues()
        Dim submittedValue As Object
        For Each submittedValue In myArrayList
            Dim myParameterDiscreteValue As ParameterDiscreteValue = New ParameterDiscreteValue()
            myParameterDiscreteValue.Value = submittedValue.ToString()
            currentParameterValues.Add(myParameterDiscreteValue)
        Next

        Dim myParameterFieldDefinitions As ParameterFieldDefinitions = myReportDocument.DataDefinition.ParameterFields
        Dim myParameterFieldDefinition As ParameterFieldDefinition = myParameterFieldDefinitions(PARAMETER_FIELD_NAME)
        myParameterFieldDefinition.ApplyCurrentValues(currentParameterValues)
    End Sub

    Private Function GetDefaultValuesFromParameterField(ByVal myReportDocument As ReportDocument) As ArrayList
        Dim myParameterFieldDefinitions As ParameterFieldDefinitions = myReportDocument.DataDefinition.ParameterFields
        Dim myParameterFieldDefinition As ParameterFieldDefinition = myParameterFieldDefinitions(PARAMETER_FIELD_NAME)
        Dim defaultParameterValues As ParameterValues = myParameterFieldDefinition.DefaultValues

        Dim myArrayList As ArrayList = New ArrayList()

        Dim myParameterValue As ParameterValue
        For Each myParameterValue In defaultParameterValues
            If (Not myParameterValue.IsRange) Then
                Dim myParameterDiscreteValue As ParameterDiscreteValue = CType(myParameterValue, ParameterDiscreteValue)
                myArrayList.Add(myParameterDiscreteValue.Value.ToString())
            End If
        Next
        Return myArrayList
    End Function


    Friend WithEvents orderEndDate As System.Windows.Forms.TextBox
    Friend WithEvents orderStartDate As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label

    Private Sub redisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redisplay.Click
        Dim myArrayList As ArrayList = New ArrayList()

        Dim item As String
        For Each item In defaultParameterValuesList.SelectedItems
            myArrayList.Add(item)
        Next

        SetCurrentValuesForParameterField(customersByCityReport, myArrayList)

        Dim startDate As String = orderStartDate.Text
        Dim endDate As String = orderEndDate.Text
        SetDateRangeForOrders(customersByCityReport, startDate, endDate)

        myCrystalReportViewer.ReportSource = customersByCityReport
    End Sub

    Private Sub SetDateRangeForOrders(ByVal myReportDocument As ReportDocument, ByVal startDate As String, ByVal endDate As String)
        Dim myParameterRangeValue As ParameterRangeValue = New ParameterRangeValue()
        myParameterRangeValue.StartValue = startDate
        myParameterRangeValue.EndValue = endDate
        myParameterRangeValue.LowerBoundType = RangeBoundType.BoundInclusive
        myParameterRangeValue.UpperBoundType = RangeBoundType.BoundInclusive

        Dim myParameterFields As ParameterFields = myReportDocument.ParameterFields
        Dim myParameterField As ParameterField = myParameterFields(SUBREPORT_PARAMETER_FIELD_NAME, SUBREPORT_NAME)
        myParameterField.CurrentValues.Clear()
        myParameterField.CurrentValues.Add(myParameterRangeValue)

    End Sub
End Class
