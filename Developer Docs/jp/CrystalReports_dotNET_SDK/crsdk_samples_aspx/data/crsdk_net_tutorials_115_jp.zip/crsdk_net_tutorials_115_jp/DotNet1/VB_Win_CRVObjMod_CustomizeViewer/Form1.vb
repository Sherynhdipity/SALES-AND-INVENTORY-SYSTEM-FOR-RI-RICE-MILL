Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared



Public Class Form1
    Inherits System.Windows.Forms.Form

    Private Sub ConfigureCrystalReports()
        listCRVToolbar.DataSource = System.Enum.GetValues(GetType(CeWndCRVToolbarOptions))
        selectBackColor.DataSource = System.Enum.GetValues(GetType(KnownColor))
        toolbar.Checked = myCrystalReportViewer.DisplayToolbar
        groupTree.Checked = myCrystalReportViewer.DisplayGroupTree


        myCrystalReportViewer.ReportSource = "C:\Program Files\Business Objects\Crystal Reports 11.5\Samples\en\Reports\Feature Examples\Chart.rpt"
    End Sub

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        ConfigureCrystalReports()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents myCrystalReportViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents listCRVToolbar As System.Windows.Forms.ListBox
    Friend WithEvents redisplay As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents selectBackColor As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents toolbar As System.Windows.Forms.CheckBox
    Friend WithEvents groupTree As System.Windows.Forms.CheckBox
    Friend WithEvents pageNumber As System.Windows.Forms.TextBox
    Friend WithEvents btnGoToPage As System.Windows.Forms.Button
    Friend WithEvents zoomFactor As System.Windows.Forms.TextBox
    Friend WithEvents updateZoomFactor As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents searchText As System.Windows.Forms.TextBox
    Friend WithEvents search As System.Windows.Forms.Button
    Friend WithEvents message As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.myCrystalReportViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.Label1 = New System.Windows.Forms.Label
        Me.listCRVToolbar = New System.Windows.Forms.ListBox
        Me.redisplay = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.selectBackColor = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.toolbar = New System.Windows.Forms.CheckBox
        Me.groupTree = New System.Windows.Forms.CheckBox
        Me.pageNumber = New System.Windows.Forms.TextBox
        Me.btnGoToPage = New System.Windows.Forms.Button
        Me.zoomFactor = New System.Windows.Forms.TextBox
        Me.updateZoomFactor = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.searchText = New System.Windows.Forms.TextBox
        Me.search = New System.Windows.Forms.Button
        Me.message = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'myCrystalReportViewer
        '
        Me.myCrystalReportViewer.ActiveViewIndex = -1
        Me.myCrystalReportViewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.myCrystalReportViewer.Location = New System.Drawing.Point(0, 176)
        Me.myCrystalReportViewer.Name = "myCrystalReportViewer"
        Me.myCrystalReportViewer.ReportSource = Nothing
        Me.myCrystalReportViewer.Size = New System.Drawing.Size(720, 280)
        Me.myCrystalReportViewer.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(296, 24)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Select the options for your CrystalReportViewer toolbar"
        '
        'listCRVToolbar
        '
        Me.listCRVToolbar.Location = New System.Drawing.Point(312, 8)
        Me.listCRVToolbar.Name = "listCRVToolbar"
        Me.listCRVToolbar.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.listCRVToolbar.Size = New System.Drawing.Size(120, 69)
        Me.listCRVToolbar.TabIndex = 2
        '
        'redisplay
        '
        Me.redisplay.Location = New System.Drawing.Point(576, 88)
        Me.redisplay.Name = "redisplay"
        Me.redisplay.Size = New System.Drawing.Size(120, 23)
        Me.redisplay.TabIndex = 3
        Me.redisplay.Text = "Redisplay Report"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(440, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Select background color"
        '
        'selectBackColor
        '
        Me.selectBackColor.Location = New System.Drawing.Point(568, 8)
        Me.selectBackColor.Name = "selectBackColor"
        Me.selectBackColor.Size = New System.Drawing.Size(121, 21)
        Me.selectBackColor.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(144, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(232, 23)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Select the report components to display"
        '
        'toolbar
        '
        Me.toolbar.Location = New System.Drawing.Point(392, 88)
        Me.toolbar.Name = "toolbar"
        Me.toolbar.TabIndex = 7
        Me.toolbar.Text = "Toolbar"
        '
        'groupTree
        '
        Me.groupTree.Location = New System.Drawing.Point(392, 112)
        Me.groupTree.Name = "groupTree"
        Me.groupTree.TabIndex = 8
        Me.groupTree.Text = "Group Tree"
        '
        'pageNumber
        '
        Me.pageNumber.Location = New System.Drawing.Point(144, 112)
        Me.pageNumber.Name = "pageNumber"
        Me.pageNumber.TabIndex = 9
        Me.pageNumber.Text = ""
        '
        'btnGoToPage
        '
        Me.btnGoToPage.Location = New System.Drawing.Point(248, 112)
        Me.btnGoToPage.Name = "btnGoToPage"
        Me.btnGoToPage.TabIndex = 10
        Me.btnGoToPage.Text = "Go To Page"
        '
        'zoomFactor
        '
        Me.zoomFactor.Location = New System.Drawing.Point(144, 144)
        Me.zoomFactor.Name = "zoomFactor"
        Me.zoomFactor.TabIndex = 11
        Me.zoomFactor.Text = ""
        '
        'updateZoomFactor
        '
        Me.updateZoomFactor.Location = New System.Drawing.Point(248, 144)
        Me.updateZoomFactor.Name = "updateZoomFactor"
        Me.updateZoomFactor.TabIndex = 12
        Me.updateZoomFactor.Text = "Zoom"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(328, 144)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 23)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "%"
        '
        'searchText
        '
        Me.searchText.Location = New System.Drawing.Point(392, 144)
        Me.searchText.Name = "searchText"
        Me.searchText.TabIndex = 14
        Me.searchText.Text = ""
        '
        'search
        '
        Me.search.Location = New System.Drawing.Point(496, 144)
        Me.search.Name = "search"
        Me.search.TabIndex = 15
        Me.search.Text = "Search"
        '
        'message
        '
        Me.message.Location = New System.Drawing.Point(576, 144)
        Me.message.Name = "message"
        Me.message.Size = New System.Drawing.Size(136, 23)
        Me.message.TabIndex = 16
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(720, 454)
        Me.Controls.Add(Me.message)
        Me.Controls.Add(Me.search)
        Me.Controls.Add(Me.searchText)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.updateZoomFactor)
        Me.Controls.Add(Me.zoomFactor)
        Me.Controls.Add(Me.btnGoToPage)
        Me.Controls.Add(Me.pageNumber)
        Me.Controls.Add(Me.groupTree)
        Me.Controls.Add(Me.toolbar)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.selectBackColor)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.redisplay)
        Me.Controls.Add(Me.listCRVToolbar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.myCrystalReportViewer)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub redisplay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles redisplay.Click
        myCrystalReportViewer.ShowPageNavigateButtons = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Page_Navigation)
        myCrystalReportViewer.ShowGotoPageButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Go_to_Page)
        myCrystalReportViewer.ShowCloseButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Close_View)
        myCrystalReportViewer.ShowPrintButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Print)
        myCrystalReportViewer.ShowRefreshButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Refresh)
        myCrystalReportViewer.ShowExportButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Export)
        myCrystalReportViewer.ShowGroupTreeButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Group_Tree)
        myCrystalReportViewer.ShowZoomButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Zoom)
        myCrystalReportViewer.ShowTextSearchButton = listCRVToolbar.GetSelected(CeWndCRVToolbarOptions.Search)

        Dim mySelectedKnownColor As KnownColor = CType(selectBackColor.SelectedItem, KnownColor)
        If Not mySelectedKnownColor = KnownColor.Transparent Then
            myCrystalReportViewer.BackColor = System.Drawing.Color.FromKnownColor(mySelectedKnownColor)
        End If
        myCrystalReportViewer.DisplayToolbar = toolbar.Checked
        myCrystalReportViewer.DisplayGroupTree = groupTree.Checked
    End Sub

    Private Sub btnGoToPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGoToPage.Click
        myCrystalReportViewer.ShowNthPage(Convert.ToInt32(pageNumber.Text))
    End Sub

    Private Sub updateZoomFactor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles updateZoomFactor.Click
        myCrystalReportViewer.Zoom(Convert.ToInt32(zoomFactor.Text))
    End Sub

    Private Sub search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles search.Click
        Dim mySearchResult As Boolean = myCrystalReportViewer.SearchForText(searchText.Text)
        If mySearchResult Then
            message.Text = "Search results found."
        Else
            message.Text = "Search results not found."
        End If
    End Sub
End Class
